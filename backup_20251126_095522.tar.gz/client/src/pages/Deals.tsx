import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

const STAGES = ['Cold', 'Contacted', 'Demo', 'Trial', 'Negotiation', 'Closed Won', 'Closed Lost'];

export default function Deals() {
  const { user, logout } = useAuth();
  const { data: deals, isLoading } = trpc.deals.list.useQuery();

  const dealsByStage = STAGES.reduce((acc, stage) => {
    acc[stage] = deals?.filter(d => d.stage === stage) || [];
    return acc;
  }, {} as Record<string, typeof deals>);

  return (
    <div className="bg-white">
      <main className="container py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-black mb-2">Sales Pipeline</h2>
          <p className="text-gray-600">Übersicht aller Deals</p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="text-lg text-gray-600">Loading...</div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="flex gap-6 pb-4" style={{ minWidth: 'max-content' }}>
              {STAGES.map((stage) => (
                <div key={stage} className="flex-shrink-0" style={{ width: '300px' }}>
                  <Card className="border-2 border-gray-300 h-full">
                    <CardHeader className="border-b-2 border-gray-300">
                      <CardTitle className="text-sm font-bold text-black uppercase">
                        {stage}
                      </CardTitle>
                      <div className="text-xs text-gray-600">
                        {dealsByStage[stage]?.length || 0} Deals
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4 space-y-3">
                      {dealsByStage[stage]?.length === 0 ? (
                        <div className="text-sm text-gray-400 text-center py-8">
                          Keine Deals
                        </div>
                      ) : (
                        dealsByStage[stage]?.map((deal) => (
                          <Card key={deal.id} className="border border-gray-300 bg-gray-50">
                            <CardContent className="p-4">
                              <div className="font-medium text-black text-sm mb-2">
                                {deal.dealName}
                              </div>
                              <div className="text-xs text-gray-600 mb-2">
                                {deal.dealValueEur ? `€${Number(deal.dealValueEur).toLocaleString()}` : 'Kein Wert'}
                              </div>
                              <div className="text-xs text-gray-500">
                                {deal.probability}% Wahrscheinlichkeit
                              </div>
                              {deal.subscriptionTier && (
                                <div className="mt-2 text-xs">
                                  <span className="px-2 py-1 border border-gray-400 bg-white text-black">
                                    {deal.subscriptionTier}
                                  </span>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}


import { useParams, useLocation, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import ActivityTimeline from "@/components/ActivityTimeline";
import QuickActions from "@/components/QuickActions";

/**
 * Corporation Detail View mit 3-Column-Layout (Pipedrive/HubSpot-inspiriert)
 * 
 * Layout:
 * - Left Sidebar: Key Facts + Quick Stats
 * - Main Area: Tabs (Overview, Activities)
 * - Right Sidebar: Associations (Companies, Contacts, Deals)
 */

export default function CorporationDetailNew() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  // Edit state
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editData, setEditData] = useState({
    name: "",
    industry: "",
    headquartersCountry: "",
    website: "",
    linkedinUrl: "",
    notes: "",
    status: "",
    priority: ""
  });

  // Data fetching
  const { data: corporation, isLoading: corpLoading } = trpc.corporations.get.useQuery({ id: id! });
  const { data: companies } = trpc.companies.listByCorporation.useQuery({ corporationId: id! });
  const { data: deals } = trpc.deals.listByCorporation.useQuery({ corporationId: id! });
  const { data: activities } = trpc.activities.listByCorporation.useQuery({ corporationId: id! });

  // Update mutation
  const updateCorporationMutation = trpc.corporations.update.useMutation({
    onSuccess: () => {
      utils.corporations.get.invalidate({ id: id! });
      setIsEditOpen(false);
    },
  });

  const handleEdit = () => {
    if (corporation) {
      setEditData({
        name: corporation.name || "",
        industry: corporation.industry || "",
        headquartersCountry: corporation.headquartersCountry || "",
        website: corporation.website || "",
        linkedinUrl: corporation.linkedinUrl || "",
        notes: corporation.notes || "",
        status: corporation.status || "",
        priority: corporation.priority || ""
      });
      setIsEditOpen(true);
    }
  };

  const handleSave = () => {
    updateCorporationMutation.mutate({
      id: id!,
      ...editData
    });
  };

  if (corpLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-muted-foreground">Lädt...</div>
      </div>
    );
  }

  if (!corporation) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-muted-foreground">Konzern nicht gefunden</div>
      </div>
    );
  }

  // Calculate deal stats
  const dealStats = deals?.reduce(
    (acc, deal) => {
      const value = Number(deal.dealValueEur) || 0;
      if (deal.stage === "Closed Won") {
        acc.won.count++;
        acc.won.value += value;
      } else if (deal.stage === "Closed Lost") {
        acc.lost.count++;
        acc.lost.value += value;
      } else {
        acc.open.count++;
        acc.open.value += value;
      }
      return acc;
    },
    { won: { count: 0, value: 0 }, lost: { count: 0, value: 0 }, open: { count: 0, value: 0 } }
  ) || { won: { count: 0, value: 0 }, lost: { count: 0, value: 0 }, open: { count: 0, value: 0 } };

  const totalDeals = dealStats.won.count + dealStats.lost.count + dealStats.open.count;
  const totalValue = dealStats.won.value + dealStats.lost.value + dealStats.open.value;

  // Status badge class
  const getStatusClass = (status: string) => {
    const statusLower = status.toLowerCase();
    if (statusLower === "customer") return "status-customer";
    if (statusLower === "negotiation") return "status-negotiation";
    if (statusLower === "contacted") return "status-contacted";
    if (statusLower === "target") return "status-target";
    if (statusLower === "lost") return "status-lost";
    return "status-target";
  };

  // Priority stars
  const getPriorityStars = (priority: string) => {
    if (priority === "High") return "★★★";
    if (priority === "Medium") return "★★☆";
    return "★☆☆";
  };

  const getPriorityClass = (priority: string) => {
    if (priority === "High") return "priority-high";
    if (priority === "Medium") return "priority-medium";
    return "priority-low";
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate("/corporations")}>
              ← Zurück
            </Button>
            <h1 className="text-2xl font-bold">{corporation.name}</h1>
          </div>
          <Button onClick={handleEdit}>Bearbeiten</Button>
        </div>
        
        {/* Quick Actions */}
        <QuickActions
          onEmail={() => console.log("Email")}
          onCall={() => console.log("Call")}
          onMeeting={() => console.log("Meeting")}
          onNote={() => console.log("Note")}
        />
      </div>

      {/* 3-Column Layout */}
      <div className="flex-1 grid grid-cols-[280px_1fr_320px] gap-0 overflow-hidden">
        {/* LEFT SIDEBAR: Key Facts */}
        <div className="border-r border-border overflow-y-auto p-6">
          {/* Avatar/Logo Placeholder */}
          <div className="w-16 h-16 bg-muted flex items-center justify-center text-2xl font-bold mb-4">
            {corporation.name.charAt(0)}
          </div>

          {/* Name + Priority */}
          <h2 className="text-xl font-bold mb-2">{corporation.name}</h2>
          <div className={`text-sm font-medium mb-4 ${getPriorityClass(corporation.priority || "Medium")}`}>
            {getPriorityStars(corporation.priority || "Medium")} {corporation.priority || "Medium"} Priority
          </div>

          {/* Status Badge */}
          <div className={`status-badge ${getStatusClass(corporation.status || "Target")} mb-6`}>
            {corporation.status || "Target"}
          </div>

          {/* Key Facts */}
          <div className="space-y-4 mb-6">
            {corporation.headquartersCountry && (
              <div>
                <div className="text-xs text-muted-foreground">Land</div>
                <div className="font-medium">{corporation.headquartersCountry}</div>
              </div>
            )}
            {corporation.totalRevenueEur && (
              <div>
                <div className="text-xs text-muted-foreground">Umsatz</div>
                <div className="font-medium">€{(Number(corporation.totalRevenueEur) / 1000000000).toFixed(1)}B</div>
              </div>
            )}
            {corporation.industry && (
              <div>
                <div className="text-xs text-muted-foreground">Branche</div>
                <div className="font-medium">{corporation.industry}</div>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="border-t border-border pt-4">
            <div className="text-xs font-medium text-muted-foreground mb-3">Quick Stats</div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Deals</span>
                <span className="font-medium">{totalDeals}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Value</span>
                <span className="font-medium">€{(totalValue / 1000).toFixed(0)}k</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Companies</span>
                <span className="font-medium">{companies?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Contacts</span>
                <span className="font-medium">0</span>
              </div>
            </div>
          </div>
        </div>

        {/* MAIN AREA: Tabs */}
        <div className="overflow-y-auto">
          <Tabs defaultValue="overview" className="w-full">
            <div className="border-b border-border px-6">
              <TabsList className="bg-transparent">
                <TabsTrigger value="overview">Übersicht</TabsTrigger>
                <TabsTrigger value="activities">Aktivitäten</TabsTrigger>
              </TabsList>
            </div>

            {/* Overview Tab */}
            <TabsContent value="overview" className="p-6 space-y-6">
              {/* Notes */}
              <Card className="p-4">
                <h3 className="text-sm font-medium mb-2">Notizen</h3>
                <p className="text-sm text-muted-foreground">
                  {corporation.notes || "Keine Notizen vorhanden"}
                </p>
              </Card>

              {/* Links */}
              {(corporation.website || corporation.linkedinUrl) && (
                <Card className="p-4">
                  <h3 className="text-sm font-medium mb-2">Links</h3>
                  <div className="space-y-1 text-sm">
                    {corporation.website && (
                      <a href={corporation.website} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                        Website
                      </a>
                    )}
                    {corporation.linkedinUrl && (
                      <a href={corporation.linkedinUrl} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                        LinkedIn
                      </a>
                    )}
                  </div>
                </Card>
              )}

              {/* Deal Pipeline Visualization */}
              <Card className="p-4">
                <h3 className="text-sm font-medium mb-4">Deal Pipeline</h3>
                
                {/* Progress Bars */}
                <div className="space-y-3">
                  {/* Won */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span>Won: {dealStats.won.count} (€{(dealStats.won.value / 1000).toFixed(0)}k)</span>
                      <span>{totalValue > 0 ? Math.round((dealStats.won.value / totalValue) * 100) : 0}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted overflow-hidden">
                      <div 
                        className="h-full bg-[oklch(0.608_0.167_160.267)]" 
                        style={{ width: `${totalValue > 0 ? (dealStats.won.value / totalValue) * 100 : 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Lost */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span>Lost: {dealStats.lost.count} (€{(dealStats.lost.value / 1000).toFixed(0)}k)</span>
                      <span>{totalValue > 0 ? Math.round((dealStats.lost.value / totalValue) * 100) : 0}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted overflow-hidden">
                      <div 
                        className="h-full bg-[oklch(0.578_0.201_27.325)]" 
                        style={{ width: `${totalValue > 0 ? (dealStats.lost.value / totalValue) * 100 : 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Open */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span>Open: {dealStats.open.count} (€{(dealStats.open.value / 1000).toFixed(0)}k)</span>
                      <span>{totalValue > 0 ? Math.round((dealStats.open.value / totalValue) * 100) : 0}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted overflow-hidden">
                      <div 
                        className="h-full bg-[oklch(0.757_0.149_70.67)]" 
                        style={{ width: `${totalValue > 0 ? (dealStats.open.value / totalValue) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4">
                  + Deal hinzufügen
                </Button>
              </Card>
            </TabsContent>

            {/* Activities Tab */}
            <TabsContent value="activities" className="p-6">
              <ActivityTimeline activities={activities || []} />
            </TabsContent>
          </Tabs>
        </div>

        {/* RIGHT SIDEBAR: Associations */}
        <div className="border-l border-border overflow-y-auto p-6">
          {/* Companies */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium">Companies ({companies?.length || 0})</h3>
              <Button size="sm" variant="ghost">+ Add</Button>
            </div>
            {companies && companies.length > 0 ? (
              <div className="space-y-2">
                {companies.map((company) => (
                  <Link key={company.id} href={`/companies/${company.id}`}>
                    <a className="block text-sm hover:underline">{company.name}</a>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Keine Firmen</p>
            )}
          </div>

          {/* Contacts */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium">Contacts (0)</h3>
              <Button size="sm" variant="ghost">+ Add</Button>
            </div>
            <p className="text-sm text-muted-foreground">Keine Kontakte</p>
          </div>

          {/* Deals */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium">Deals ({deals?.length || 0})</h3>
              <Button size="sm" variant="ghost">+ Add</Button>
            </div>
            {deals && deals.length > 0 ? (
              <div className="space-y-2">
                {deals.map((deal) => (
                  <div key={deal.id} className="text-sm">
                    <div className="font-medium">{deal.dealName}</div>
                    <div className="text-xs text-muted-foreground">
                      €{Number(deal.dealValueEur).toLocaleString()} • {deal.stage}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Keine Deals</p>
            )}
          </div>
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Konzern bearbeiten</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={editData.name}
                onChange={(e) => setEditData({ ...editData, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="industry">Branche</Label>
              <Input
                id="industry"
                value={editData.industry}
                onChange={(e) => setEditData({ ...editData, industry: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="country">Land</Label>
              <Input
                id="country"
                value={editData.headquartersCountry}
                onChange={(e) => setEditData({ ...editData, headquartersCountry: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={editData.website}
                onChange={(e) => setEditData({ ...editData, website: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="linkedin">LinkedIn URL</Label>
              <Input
                id="linkedin"
                value={editData.linkedinUrl}
                onChange={(e) => setEditData({ ...editData, linkedinUrl: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Input
                id="status"
                value={editData.status}
                onChange={(e) => setEditData({ ...editData, status: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="priority">Priorität</Label>
              <Input
                id="priority"
                value={editData.priority}
                onChange={(e) => setEditData({ ...editData, priority: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notizen</Label>
              <Input
                id="notes"
                value={editData.notes}
                onChange={(e) => setEditData({ ...editData, notes: e.target.value })}
              />
            </div>
            <Button
              onClick={handleSave}
              disabled={!editData.name || updateCorporationMutation.isPending}
              className="w-full"
            >
              {updateCorporationMutation.isPending ? "Speichert..." : "Speichern"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}


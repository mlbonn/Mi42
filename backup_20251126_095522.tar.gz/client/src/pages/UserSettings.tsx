import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Loader2, Calendar, Mail, Lock } from 'lucide-react';

export default function UserSettings() {
  const [caldavEmail, setCaldavEmail] = useState('');
  const [caldavPassword, setCaldavPassword] = useState('');
  const [caldavEnabled, setCaldavEnabled] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Load current settings
  const { data: settings, isLoading } = trpc.users.getCalDAVSettings.useQuery();
  const updateSettings = trpc.users.updateCalDAVSettings.useMutation();

  // Initialize form when data loads
  useState(() => {
    if (settings) {
      setCaldavEmail(settings.caldavEmail || '');
      setCaldavEnabled(settings.caldavEnabled || false);
    }
  });

  const handleSave = async () => {
    if (!caldavEmail || !caldavPassword) {
      toast.error('Bitte E-Mail und Passwort eingeben');
      return;
    }

    setIsSaving(true);
    try {
      await updateSettings.mutateAsync({
        caldavEmail,
        caldavPassword,
        caldavEnabled,
      });

      toast.success('CalDAV-Einstellungen wurden erfolgreich gespeichert');
    } catch (error: any) {
      toast.error(error.message || 'Speichern fehlgeschlagen');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="container max-w-2xl py-8">
      <h1 className="text-3xl font-bold mb-8">Benutzer-Einstellungen</h1>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Kalender-Integration (CalDAV)
          </CardTitle>
          <CardDescription>
            Verbinden Sie Ihren SmarterMail-Kalender mit FRIDAY CRM
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="caldavEmail" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              E-Mail-Adresse (SmarterMail)
            </Label>
            <Input
              id="caldavEmail"
              type="email"
              placeholder="beispiel@bl2020.com"
              value={caldavEmail}
              onChange={(e) => setCaldavEmail(e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Ihre SmarterMail E-Mail-Adresse für den Kalender-Zugriff
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="caldavPassword" className="flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Passwort
            </Label>
            <Input
              id="caldavPassword"
              type="password"
              placeholder="Ihr SmarterMail-Passwort"
              value={caldavPassword}
              onChange={(e) => setCaldavPassword(e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Ihr SmarterMail-Passwort (wird verschlüsselt gespeichert)
            </p>
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="space-y-0.5">
              <Label htmlFor="caldavEnabled" className="text-base">
                Kalender-Synchronisation aktivieren
              </Label>
              <p className="text-sm text-muted-foreground">
                Ihre Termine werden automatisch synchronisiert
              </p>
            </div>
            <Switch
              id="caldavEnabled"
              checked={caldavEnabled}
              onCheckedChange={setCaldavEnabled}
            />
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <h4 className="font-medium text-sm">ℹ️ Hinweise:</h4>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li>Verwenden Sie Ihre normale SmarterMail E-Mail und Passwort</li>
              <li>Das Passwort wird sicher verschlüsselt gespeichert</li>
              <li>Nach dem Aktivieren erscheinen Ihre Termine im Team-Kalender</li>
              <li>Änderungen werden in beide Richtungen synchronisiert</li>
            </ul>
          </div>

          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="w-full"
            size="lg"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Speichern...
              </>
            ) : (
              'Einstellungen speichern'
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}


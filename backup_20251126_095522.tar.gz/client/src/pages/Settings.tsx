import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { trpc } from '@/lib/trpc';
import { Eye, EyeOff, Save, Key, RefreshCw, Settings as SettingsIcon } from 'lucide-react';

interface ApiKey {
  id: string;
  name: string;
  service: string;
  key: string;
  description: string;
  lastUsed?: Date;
  status: 'active' | 'inactive' | 'error';
}

export default function Settings() {
  const utils = trpc.useUtils();
  
  // API Keys State
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});

  // Scout Settings State
  const [scoutSettings, setScoutSettings] = useState({
    minRevenueMio: 100,
    minEmployees: 500,
    companyTypes: ['Manufacturer'],
    targetMarkets: ['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'],
  });

  const { data: savedKeys, isLoading } = trpc.settings.getApiKeys.useQuery();
  const { data: savedScoutSettings } = trpc.settings.getScoutSettings.useQuery();
  
  const saveKeysMutation = trpc.settings.saveApiKeys.useMutation({
    onSuccess: () => {
      utils.settings.getApiKeys.invalidate();
      alert('API Keys gespeichert!');
    },
  });

  const testKeyMutation = trpc.settings.testApiKey.useMutation();

  const toggleKeyVisibility = (keyName: string) => {
    setShowKeys(prev => ({ ...prev, [keyName]: !prev[keyName] }));
  };

  const handleSave = () => {
    saveKeysMutation.mutate(apiKeys);
  };

  const saveScoutSettingsMutation = trpc.settings.saveScoutSettings.useMutation({
    onSuccess: () => {
      utils.settings.getScoutSettings.invalidate();
      alert('Scout Agent Filter gespeichert!');
    },
  });

  const handleSaveScoutSettings = () => {
    saveScoutSettingsMutation.mutate(scoutSettings);
  };

  // Load saved scout settings
  useEffect(() => {
    if (savedScoutSettings) {
      setScoutSettings({
        minRevenueMio: savedScoutSettings.minRevenueMio || 100,
        minEmployees: savedScoutSettings.minEmployees || 500,
        companyTypes: savedScoutSettings.companyTypes || ['Manufacturer'],
        targetMarkets: savedScoutSettings.targetMarkets || ['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'],
      });
    }
  }, [savedScoutSettings]);

  const handleTestKey = async (service: string) => {
    const result = await testKeyMutation.mutateAsync({ service, key: apiKeys[service] });
    alert(result.success ? `✅ ${service} Key funktioniert!` : `❌ ${service} Key ungültig: ${result.error}`);
  };

  const keyConfigs = [
    {
      id: 'openai',
      name: 'OpenAI API Key',
      service: 'OpenAI',
      description: 'Für GPT-4 E-Mail-Generierung und Sentiment-Analyse',
      placeholder: 'sk-...',
      docs: 'https://platform.openai.com/api-keys',
    },
    {
      id: 'apollo',
      name: 'Apollo.io API Key',
      service: 'Apollo.io',
      description: 'Für Kontakt-Suche und E-Mail-Finder',
      placeholder: 'apollo_...',
      docs: 'https://apolloio.github.io/apollo-api-docs/',
    },
    {
      id: 'linkedin',
      name: 'LinkedIn Sales Navigator API',
      service: 'LinkedIn',
      description: 'Für Konzern-Discovery und Kontakt-Anreicherung',
      placeholder: 'linkedin_...',
      docs: 'https://docs.microsoft.com/en-us/linkedin/',
    },
    {
      id: 'hunter',
      name: 'Hunter.io API Key',
      service: 'Hunter.io',
      description: 'Für E-Mail-Finder und Domain-Suche',
      placeholder: 'hunter_...',
      docs: 'https://hunter.io/api-documentation',
    },
    {
      id: 'zerobounce',
      name: 'ZeroBounce API Key',
      service: 'ZeroBounce',
      description: 'Für E-Mail-Validierung',
      placeholder: 'zerobounce_...',
      docs: 'https://www.zerobounce.net/docs/',
    },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Einstellungen</h1>
        <p className="text-gray-600">Verwalte API-Keys und System-Konfiguration</p>
      </div>

      <Tabs defaultValue="api-keys" className="space-y-6">
        <TabsList>
          <TabsTrigger value="api-keys">
            <Key className="mr-2 h-4 w-4" />
            API Keys
          </TabsTrigger>
          <TabsTrigger value="scout-agent">
            <SettingsIcon className="mr-2 h-4 w-4" />
            Scout Agent
          </TabsTrigger>
          <TabsTrigger value="smtp">
            <RefreshCw className="mr-2 h-4 w-4" />
            SMTP / E-Mail
          </TabsTrigger>
        </TabsList>

        <TabsContent value="api-keys" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>API Keys verwalten</CardTitle>
              <CardDescription>
                Konfiguriere externe Services für Scout, Hunter und Outreach Agenten
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {keyConfigs.map((config) => (
                <div key={config.id} className="border-b pb-6 last:border-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <Label htmlFor={config.id} className="text-base font-semibold">
                        {config.name}
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">{config.description}</p>
                    </div>
                    <a
                      href={config.docs}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline"
                    >
                      Docs →
                    </a>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <div className="relative flex-1">
                      <Input
                        id={config.id}
                        type={showKeys[config.id] ? 'text' : 'password'}
                        value={apiKeys[config.id] || (savedKeys as Record<string, string>)?.[config.id] || ''}
                        onChange={(e) => setApiKeys({ ...apiKeys, [config.id]: e.target.value })}
                        placeholder={config.placeholder}
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => toggleKeyVisibility(config.id)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showKeys[config.id] ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleTestKey(config.id)}
                      disabled={!apiKeys[config.id] && !(savedKeys as Record<string, string>)?.[config.id]}
                    >
                      Test
                    </Button>
                  </div>
                </div>
              ))}

              <div className="flex justify-end pt-4">
                <Button onClick={handleSave} disabled={saveKeysMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  {saveKeysMutation.isPending ? 'Speichere...' : 'Alle Keys speichern'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scout-agent" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scout Agent Filter-Einstellungen</CardTitle>
              <CardDescription>
                Konfiguriere Filter für automatische Competitor Discovery
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="min_revenue">Mindest-Umsatz (Mio EUR)</Label>
                  <Input
                    id="min_revenue"
                    type="number"
                    placeholder="100"
                    value={scoutSettings.minRevenueMio}
                    onChange={(e) => setScoutSettings({ ...scoutSettings, minRevenueMio: parseInt(e.target.value) || 0 })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Nur Firmen über diesem Umsatz</p>
                </div>
                <div>
                  <Label htmlFor="min_employees">Mindest-Mitarbeiter</Label>
                  <Input
                    id="min_employees"
                    type="number"
                    placeholder="500"
                    value={scoutSettings.minEmployees}
                    onChange={(e) => setScoutSettings({ ...scoutSettings, minEmployees: parseInt(e.target.value) || 0 })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Oder über dieser Mitarbeiterzahl</p>
                </div>
              </div>

                <div>
                <Label>Firmentypen (mehrfach wählbar)</Label>
                <div className="space-y-2 mt-2">
                  {['Manufacturer', 'Distributor', 'Service Provider'].map(type => (
                    <label key={type} className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        checked={scoutSettings.companyTypes.includes(type)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setScoutSettings({ ...scoutSettings, companyTypes: [...scoutSettings.companyTypes, type] });
                          } else {
                            setScoutSettings({ ...scoutSettings, companyTypes: scoutSettings.companyTypes.filter(t => t !== type) });
                          }
                        }}
                        className="rounded" 
                      />
                      <span className="text-sm">{type === 'Manufacturer' ? 'Hersteller' : type === 'Distributor' ? 'Händler' : 'Dienstleister'} ({type})</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <Label>Zielmärkte (Länder)</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'].map(country => (
                    <label key={country} className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        checked={scoutSettings.targetMarkets.includes(country)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setScoutSettings({ ...scoutSettings, targetMarkets: [...scoutSettings.targetMarkets, country] });
                          } else {
                            setScoutSettings({ ...scoutSettings, targetMarkets: scoutSettings.targetMarkets.filter(c => c !== country) });
                          }
                        }}
                        className="rounded" 
                      />
                      <span className="text-sm font-mono">{country}</span>
                    </label>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">Top-15 Märkte für Competitor Discovery</p>
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button onClick={handleSaveScoutSettings} disabled={saveScoutSettingsMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  {saveScoutSettingsMutation.isPending ? 'Speichere...' : 'Filter speichern'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="smtp" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>SMTP / E-Mail Konfiguration</CardTitle>
              <CardDescription>
                Konfiguriere SmarterMail oder anderen SMTP-Server für E-Mail-Versand
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="smtp_host">SMTP Host</Label>
                <Input
                  id="smtp_host"
                  value={apiKeys.smtp_host || (savedKeys as Record<string, string>)?.smtp_host || ''}
                  onChange={(e) => setApiKeys({ ...apiKeys, smtp_host: e.target.value })}
                  placeholder="mail.example.com"
                />
              </div>
              <div>
                <Label htmlFor="smtp_port">SMTP Port</Label>
                <Input
                  id="smtp_port"
                  value={apiKeys.smtp_port || (savedKeys as Record<string, string>)?.smtp_port || ''}
                  onChange={(e) => setApiKeys({ ...apiKeys, smtp_port: e.target.value })}
                  placeholder="587"
                />
              </div>
              <div>
                <Label htmlFor="smtp_user">SMTP Username</Label>
                <Input
                  id="smtp_user"
                  value={apiKeys.smtp_user || (savedKeys as Record<string, string>)?.smtp_user || ''}
                  onChange={(e) => setApiKeys({ ...apiKeys, smtp_user: e.target.value })}
                  placeholder="user@example.com"
                />
              </div>
              <div>
                <Label htmlFor="smtp_password">SMTP Password</Label>
                <div className="relative">
                  <Input
                    id="smtp_password"
                    type={showKeys.smtp_password ? 'text' : 'password'}
                    value={apiKeys.smtp_password || (savedKeys as Record<string, string>)?.smtp_password || ''}
                    onChange={(e) => setApiKeys({ ...apiKeys, smtp_password: e.target.value })}
                    placeholder="••••••••"
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => toggleKeyVisibility('smtp_password')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showKeys.smtp_password ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => handleTestKey('smtp')}
                  disabled={!apiKeys.smtp_host || !apiKeys.smtp_user}
                >
                  SMTP Verbindung testen
                </Button>
                <Button onClick={handleSave} disabled={saveKeysMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  Speichern
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}


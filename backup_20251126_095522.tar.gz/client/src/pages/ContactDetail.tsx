import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Link, useParams } from "wouter";
import { useState } from "react";

export default function ContactDetail() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const utils = trpc.useUtils();
  
  const [isAddCompanyOpen, setIsAddCompanyOpen] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState("");
  const [companyEmail, setCompanyEmail] = useState("");
  const [companyPosition, setCompanyPosition] = useState("");
  const [selectedEmail, setSelectedEmail] = useState<any>(null);
  
  const { data: contact, isLoading: contactLoading } = trpc.contacts.get.useQuery({ id: id! });
  
  // Get all companies for this contact
  const { data: companies } = trpc.contacts.getCompanies.useQuery(
    { contactId: id! },
    { enabled: !!id }
  );
  const primaryCompany = companies?.find(c => c.isPrimary) || companies?.[0];
  
  const { data: corporation } = trpc.corporations.get.useQuery(
    { id: primaryCompany?.corporationId || '' },
    { enabled: !!primaryCompany?.corporationId }
  );
  
  // Get all available companies for dropdown
  const { data: allCompanies } = trpc.companies.list.useQuery();
  
  const { data: activities } = trpc.activities.listByContact.useQuery(
    { contactId: id!, limit: 20 },
    { enabled: !!id }
  );

  const addCompanyMutation = trpc.contacts.addCompany.useMutation({
    onSuccess: () => {
      utils.contacts.getCompanies.invalidate({ contactId: id! });
      setIsAddCompanyOpen(false);
      setSelectedCompanyId("");
      setCompanyEmail("");
      setCompanyPosition("");
    },
  });

  const handleAddCompany = () => {
    if (!selectedCompanyId) return;
    
    addCompanyMutation.mutate({
      contactId: id!,
      companyId: selectedCompanyId,
      email: companyEmail || undefined,
      position: companyPosition || undefined,
      isPrimary: false,
    });
  };

  if (contactLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!contact) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Kontakt nicht gefunden</div>
      </div>
    );
  }

  // Filter out companies already linked
  const availableCompanies = allCompanies?.filter(
    c => !companies?.some(linked => linked.id === c.id)
  ) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="container py-8">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm text-gray-600">
          <Link href="/corporations">
            <a className="hover:underline">Konzerne</a>
          </Link>
          {corporation && (
            <>
              {' > '}
              <Link href={`/corporations/${corporation.id}`}>
                <a className="hover:underline">{corporation.name}</a>
              </Link>
            </>
          )}
          {primaryCompany && (
            <>
              {' > '}
              <Link href={`/companies/${primaryCompany.id}`}>
                <a className="hover:underline">{primaryCompany.name}</a>
              </Link>
            </>
          )}
          {' > '}
          <span className="text-gray-900 font-medium">
            {contact.firstName} {contact.lastName}
          </span>
        </div>

        {/* Contact Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {contact.firstName} {contact.lastName}
              </h1>
              <div className="flex items-center gap-4 text-gray-600">
                {contact.jobTitle && <span>{contact.jobTitle}</span>}
                {contact.decisionMaker && <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-medium">Decision Maker</span>}
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">Bearbeiten</Button>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex gap-2 mb-8">
          <Button variant="outline" size="sm">✉ Email</Button>
          <Button variant="outline" size="sm">☎ Call</Button>
          <Button variant="outline" size="sm">📅 Meeting</Button>
          <Button variant="outline" size="sm">📝 Note</Button>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="emails" className="w-full">
          <TabsList>
            <TabsTrigger value="info">
              Informationen
            </TabsTrigger>
            <TabsTrigger value="companies">
              Firmen ({companies?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="activities">
              Aktivitäten ({activities?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="emails">
              E-Mails
            </TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Kontaktinformationen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Vorname</div>
                    <div className="text-gray-900">{contact.firstName}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Nachname</div>
                    <div className="text-gray-900">{contact.lastName}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Position</div>
                    <div className="text-gray-900">{contact.jobTitle || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Status</div>
                    <div className="text-gray-900">{contact.contactStatus || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Telefon</div>
                    <div className="text-gray-900">{contact.phone || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Mobil</div>
                    <div className="text-gray-900">{contact.mobile || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">LinkedIn</div>
                    <div className="text-gray-900">
                      {contact.linkedinUrl ? (
                        <a href={contact.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                          Profil ansehen
                        </a>
                      ) : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Decision Maker</div>
                    <div className="text-gray-900">{contact.decisionMaker ? 'Ja' : 'Nein'}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-sm text-gray-600 mb-1">Notizen</div>
                    <div className="text-gray-900">{contact.notes || '-'}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Genesis World CRM Fields */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Zusätzliche Informationen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Keyword 1</div>
                    <div className="text-gray-900">{contact.keyword1 || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Keyword 2</div>
                    <div className="text-gray-900">{contact.keyword2 || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Funktion</div>
                    <div className="text-gray-900">{contact.function || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Abteilung</div>
                    <div className="text-gray-900">{contact.department || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Kategorie</div>
                    <div className="text-gray-900">{contact.category || '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Verantwortlich</div>
                    <div className="text-gray-900">{contact.responsiblePerson || '-'}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-sm text-gray-600 mb-1">Tags</div>
                    <div className="text-gray-900">{contact.tags || '-'}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="companies" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Zugeordnete Firmen</CardTitle>
                <Button onClick={() => setIsAddCompanyOpen(true)} size="sm">
                  + Firma hinzufügen
                </Button>
              </CardHeader>
              <CardContent>
                {companies && companies.length > 0 ? (
                  <div className="space-y-4">
                    {companies.map((company) => (
                      <div key={company.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <Link href={`/companies/${company.id}`}>
                              <a className="text-lg font-semibold text-blue-600 hover:underline">
                                {company.name}
                              </a>
                            </Link>
                            {company.isPrimary && (
                              <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                Hauptfirma
                              </span>
                            )}
                            <div className="mt-2 text-sm text-gray-600">
                              {company.position && <div>Position: {company.position}</div>}
                              {company.email && <div>E-Mail: {company.email}</div>}
                              {company.city && <div>Ort: {company.city}, {company.country}</div>}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Keine Firmen zugeordnet
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activities" className="mt-6">
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              {activities && activities.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Typ</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Betreff</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Datum</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ergebnis</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {activities.map((activity: any) => (
                        <tr key={activity.id} className="hover:bg-gray-50 transition-colors cursor-pointer">
                          <td className="px-4 py-3 text-sm text-gray-900">
                            <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-700">
                              {activity.activityType}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900">{activity.subject || '-'}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {new Date(activity.activityDate).toLocaleDateString('de-DE', { 
                              day: '2-digit', 
                              month: 'short', 
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">{activity.outcome || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 text-gray-400 text-sm">
                  Keine Aktivitäten vorhanden
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="emails" className="mt-6">
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              {activities && activities.filter((a: any) => a.activityType === 'email').length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gesendet</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Absender</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Empfänger</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Betreff</th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-12">📎</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {activities
                        .filter((a: any) => a.activityType === 'email')
                        .sort((a: any, b: any) => new Date(b.activityDate).getTime() - new Date(a.activityDate).getTime())
                        .map((email: any) => (
                        <tr key={email.id} className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => setSelectedEmail(email)}>
                          <td className="px-4 py-3 text-sm text-gray-600 whitespace-nowrap">
                            {new Date(email.activityDate).toLocaleDateString('de-DE', { 
                              day: '2-digit', 
                              month: '2-digit', 
                              year: 'numeric'
                            })}
                            {' '}
                            {new Date(email.activityDate).toLocaleTimeString('de-DE', { 
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900">
                            {email.direction === 'outbound' 
                              ? (contact.primaryEmail || contact.firstName + ' ' + contact.lastName)
                              : (email.fromEmail || '-')
                            }
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900">
                            {email.direction === 'outbound'
                              ? (email.toEmail || '-')
                              : (contact.primaryEmail || contact.firstName + ' ' + contact.lastName)
                            }
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-900">{email.subject || 'Kein Betreff'}</td>
                          <td className="px-4 py-3 text-center text-gray-400">
                            {email.hasAttachment ? '📎' : ''}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 text-gray-400 text-sm">
                  Keine E-Mails vorhanden
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Add Company Dialog */}
      <Dialog open={isAddCompanyOpen} onOpenChange={setIsAddCompanyOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Firma hinzufügen</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="company">Firma auswählen *</Label>
              <select
                id="company"
                className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                value={selectedCompanyId}
                onChange={(e) => setSelectedCompanyId(e.target.value)}
              >
                <option value="">Bitte wählen...</option>
                {availableCompanies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name} ({company.city}, {company.country})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label htmlFor="email">E-Mail bei dieser Firma</Label>
              <Input
                id="email"
                type="email"
                value={companyEmail}
                onChange={(e) => setCompanyEmail(e.target.value)}
                placeholder="z.B. peter.test@firma.de"
              />
            </div>
            <div>
              <Label htmlFor="position">Position bei dieser Firma</Label>
              <Input
                id="position"
                value={companyPosition}
                onChange={(e) => setCompanyPosition(e.target.value)}
                placeholder="z.B. Geschäftsführer"
              />
            </div>
            <Button
              onClick={handleAddCompany}
              disabled={!selectedCompanyId || addCompanyMutation.isPending}
              className="w-full"
            >
              {addCompanyMutation.isPending ? "Füge hinzu..." : "Firma hinzufügen"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Email Preview Modal - Larger & Resizable */}
      <Dialog open={selectedEmail !== null} onOpenChange={() => setSelectedEmail(null)}>
        <DialogContent className="max-w-6xl w-[90vw] h-[85vh] overflow-hidden flex flex-col resize">
          <DialogHeader className="flex-row items-start justify-between">
            <div className="flex-1">
              <DialogTitle className="text-lg font-semibold text-gray-900">E-Mail-Vorschau</DialogTitle>
            </div>
            {/* In Outlook öffnen Button - Rechts oben */}
            {selectedEmail && (
              <a
                href={`mailto:${selectedEmail.direction === 'outbound' ? selectedEmail.toEmail : selectedEmail.fromEmail}?subject=${encodeURIComponent(selectedEmail.subject || '')}&body=${encodeURIComponent(selectedEmail.content || '')}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  📬 In Outlook öffnen
                </Button>
              </a>
            )}
          </DialogHeader>
          
          {selectedEmail && (
            <>
              {/* Email Metadata */}
              <div className="border-b pb-3 space-y-2 text-sm">
                <div className="flex gap-2">
                  <span className="font-medium text-gray-500 w-20">Von:</span>
                  <span className="text-gray-900">
                    {selectedEmail.direction === 'outbound' 
                      ? (contact?.primaryEmail || `${contact?.firstName} ${contact?.lastName}`)
                      : (selectedEmail.fromEmail || '-')
                    }
                  </span>
                </div>
                <div className="flex gap-2">
                  <span className="font-medium text-gray-500 w-20">An:</span>
                  <span className="text-gray-900">
                    {selectedEmail.direction === 'outbound'
                      ? (selectedEmail.toEmail || '-')
                      : (contact?.primaryEmail || `${contact?.firstName} ${contact?.lastName}`)
                    }
                  </span>
                </div>
                <div className="flex gap-2">
                  <span className="font-medium text-gray-500 w-20">Datum:</span>
                  <span className="text-gray-600">
                    {new Date(selectedEmail.activityDate).toLocaleDateString('de-DE', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                {selectedEmail.hasAttachment && (
                  <div className="flex gap-2">
                    <span className="font-medium text-gray-500 w-20">Anhänge:</span>
                    <span className="text-gray-600">
                      📎 {selectedEmail.attachmentCount || 1} Anhang(e)
                    </span>
                  </div>
                )}
              </div>

              {/* Subject Line - Between metadata and body */}
              <div className="py-3 border-b">
                <h3 className="text-lg font-semibold text-gray-900">
                  {selectedEmail.subject || 'Kein Betreff'}
                </h3>
              </div>

              {/* Email Content - Scrollable */}
              <div className="flex-1 overflow-y-auto py-4 min-h-0">
                <div className="prose max-w-none">
                  {selectedEmail.content ? (
                    <pre className="whitespace-pre-wrap font-sans text-sm text-gray-900 leading-relaxed">
                      {selectedEmail.content}
                    </pre>
                  ) : (
                    <div className="text-center py-12 text-gray-400">
                      Kein E-Mail-Inhalt verfügbar
                    </div>
                  )}
                </div>
              </div>

              {/* Resize Handle - Bottom right corner */}
              <div className="absolute bottom-2 right-2 text-gray-400 cursor-se-resize select-none">
                ⋰
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}


import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { simpleAuthRouter } from "./simpleAuthRouter";
import { userRouter } from "./userRouter";
import { contactsRouter } from "./contactsRouter";
import { companiesRouter } from "./companiesRouter";
import { corporationsRouter } from "./corporationsRouter";
import { dealsRouter } from "./dealsRouter";
import { activitiesRouter } from "./activitiesRouter";
import { jwtAuthRouter } from "./jwtAuthRouter";
import { dashboardRouter } from "./dashboardRouter";

export const appRouter = router({
  system: systemRouter,
  auth: simpleAuthRouter,
  users: userRouter,
  contacts: contactsRouter,
  companies: companiesRouter,
  corporations: corporationsRouter,
  deals: dealsRouter,
  activities: activitiesRouter,
  jwtAuth: jwtAuthRouter,
  dashboard: dashboardRouter,
});

export type AppRouter = typeof appRouter;

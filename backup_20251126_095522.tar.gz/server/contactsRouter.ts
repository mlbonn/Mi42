import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getAllContacts,
  getContact,
  getContactsByCompany,
  getCompaniesByContact,
  createContact,
  updateContact,
  addContactToCompany,
} from "./db";

export const contactsRouter = router({
  // List all contacts with pagination
  list: publicProcedure
    .input(
      z.object({
        search: z.string().optional(),
        companyId: z.string().optional(),
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const limit = input?.limit || 50;
      const offset = input?.offset || 0;
      
      let contacts = input?.companyId
        ? await getContactsByCompany(input.companyId)
        : await getAllContacts();
      
      // Apply search filter
      if (input?.search) {
        const searchLower = input.search.toLowerCase();
        contacts = contacts.filter(
          (c: any) =>
            c.firstName?.toLowerCase().includes(searchLower) ||
            c.lastName?.toLowerCase().includes(searchLower) ||
            c.primaryEmail?.toLowerCase().includes(searchLower)
        );
      }
      
      // Apply pagination
      const total = contacts.length;
      const paginatedContacts = contacts.slice(offset, offset + limit);
      
      return {
        data: paginatedContacts,
        pagination: {
          total,
          limit,
          offset,
          hasMore: offset + limit < total,
        },
      };
    }),

  // Get single contact by ID
  get: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      return await getContact(input.id);
    }),

  // Search contacts by email
  searchByEmail: publicProcedure
    .input(z.object({ email: z.string() }))
    .query(async ({ input }) => {
      const contacts = await getAllContacts();
      return contacts.filter(
        (c: any) => c.primaryEmail?.toLowerCase() === input.email.toLowerCase()
      );
    }),

  // Get companies for a contact
  getCompanies: publicProcedure
    .input(z.object({ contactId: z.string() }))
    .query(async ({ input }) => {
      return await getCompaniesByContact(input.contactId);
    }),

  // Create new contact
  create: publicProcedure
    .input(
      z.object({
        firstName: z.string(),
        lastName: z.string(),
        email: z.string().email(),
        phone: z.string().optional(),
        phoneMobile: z.string().optional(),
        phoneOffice: z.string().optional(),
        faxOffice: z.string().optional(),
        position: z.string().optional(),
        department: z.string().optional(),
        function: z.string().optional(),
        companyId: z.string().optional(),
        isPrimary: z.boolean().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { companyId, isPrimary, ...contactData } = input;
      
      const contact = await createContact(contactData, companyId, isPrimary);
      return contact;
    }),

  // Update contact
  update: publicProcedure
    .input(
      z.object({
        id: z.string(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        phoneMobile: z.string().optional(),
        phoneOffice: z.string().optional(),
        faxOffice: z.string().optional(),
        position: z.string().optional(),
        department: z.string().optional(),
        function: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { id, ...data } = input;
      return await updateContact(id, data);
    }),

  // Add contact to company
  addCompany: publicProcedure
    .input(
      z.object({
        contactId: z.string(),
        companyId: z.string(),
        email: z.string().email().optional(),
        position: z.string().optional(),
        isPrimary: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await addContactToCompany(
        input.contactId,
        input.companyId,
        input.email,
        input.position,
        input.isPrimary
      );
    }),
});

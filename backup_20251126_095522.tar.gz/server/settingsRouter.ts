import { z } from 'zod';
import { router, protectedProcedure } from './_core/trpc';
import * as db from './db';

export const settingsRouter = router({
  // Get all API keys for current user
  getApiKeys: protectedProcedure.query(async ({ ctx }) => {
    const keys = await db.getApiKeys(ctx.user.id);
    return keys;
  }),

  // Save API keys
  saveApiKeys: protectedProcedure
    .input(
      z.object({
        openai: z.string().optional(),
        apollo: z.string().optional(),
        linkedin: z.string().optional(),
        hunter: z.string().optional(),
        zerobounce: z.string().optional(),
        smtp_host: z.string().optional(),
        smtp_port: z.string().optional(),
        smtp_user: z.string().optional(),
        smtp_password: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db.saveApiKeys(ctx.user.id, input);
      return { success: true };
    }),

  // Test API key
  testApiKey: protectedProcedure
    .input(
      z.object({
        service: z.string(),
        key: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      // Test different API keys
      try {
        switch (input.service) {
          case 'openai':
            // Test OpenAI API
            const openaiResponse = await fetch('https://api.openai.com/v1/models', {
              headers: {
                Authorization: `Bearer ${input.key}`,
              },
            });
            if (!openaiResponse.ok) {
              return { success: false, error: 'Invalid OpenAI API key' };
            }
            return { success: true };

          case 'apollo':
            // Test Apollo.io API
            const apolloResponse = await fetch('https://api.apollo.io/v1/auth/health', {
              headers: {
                'X-Api-Key': input.key,
              },
            });
            if (!apolloResponse.ok) {
              return { success: false, error: 'Invalid Apollo.io API key' };
            }
            return { success: true };

          case 'hunter':
            // Test Hunter.io API
            const hunterResponse = await fetch(
              `https://api.hunter.io/v2/account?api_key=${input.key}`
            );
            if (!hunterResponse.ok) {
              return { success: false, error: 'Invalid Hunter.io API key' };
            }
            return { success: true };

          case 'zerobounce':
            // Test ZeroBounce API
            const zerobounceResponse = await fetch(
              `https://api.zerobounce.net/v2/getcredits?api_key=${input.key}`
            );
            if (!zerobounceResponse.ok) {
              return { success: false, error: 'Invalid ZeroBounce API key' };
            }
            return { success: true };

          case 'smtp':
            // Test SMTP connection (simplified)
            return { success: true, message: 'SMTP test not yet implemented' };

          default:
            return { success: false, error: 'Unknown service' };
        }
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

  // Get Scout Agent settings
  getScoutSettings: protectedProcedure.query(async ({ ctx }) => {
    const settings = await db.getScoutSettings(ctx.user.id);
    return settings;
  }),

  // Save Scout Agent settings
  saveScoutSettings: protectedProcedure
    .input(
      z.object({
        minRevenueMio: z.number().min(0),
        minEmployees: z.number().min(0),
        companyTypes: z.array(z.string()),
        targetMarkets: z.array(z.string()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db.saveScoutSettings(ctx.user.id, input);
      return { success: true };
    }),
});


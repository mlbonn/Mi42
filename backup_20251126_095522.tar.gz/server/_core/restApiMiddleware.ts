/**
 * REST API Middleware for VSTO Add-in
 * Provides 8 REST endpoints with JWT authentication
 */

import { Router } from "express";
import jwt from "jsonwebtoken";
import {
  searchContactsByEmail,
  getAllContacts,
  createContact,
  createContactSimple,
  createActivity,
  getCompanyById,
  getCorporationById,
} from "../db";

const router = Router();

// JWT Secret from environment
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";

interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  type: "access" | "refresh";
}

/**
 * JWT Authentication Middleware
 * Verifies Bearer token and attaches user to request
 */
function authenticateJWT(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "No token provided" });
  }

  const token = authHeader.substring(7); // Remove "Bearer " prefix

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;

    if (decoded.type !== "access") {
      return res.status(401).json({ error: "Invalid token type" });
    }

    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

/**
 * GET /api/contacts/search?email=xxx
 * Search contacts by email
 */
router.get("/contacts/search", authenticateJWT, async (req, res) => {
  try {
    const { email } = req.query;

    if (!email || typeof email !== "string") {
      return res.status(400).json({ error: "Email parameter is required" });
    }

    const contacts = await searchContactsByEmail(email);

    res.json({
      data: contacts,
      count: contacts.length,
    });
  } catch (error) {
    console.error("[REST API] Search contacts error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/contacts?page=1&limit=50
 * List all contacts with pagination
 */
router.get("/contacts", authenticateJWT, async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;

    const allContacts = await getAllContacts();
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedContacts = allContacts.slice(startIndex, endIndex);

    res.json({
      data: paginatedContacts,
      pagination: {
        page,
        limit,
        total: allContacts.length,
        totalPages: Math.ceil(allContacts.length / limit),
      },
    });
  } catch (error) {
    console.error("[REST API] List contacts error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * POST /api/contacts
 * Create new contact
 */
router.post("/contacts", authenticateJWT, async (req, res) => {
  try {
    const { firstName, lastName, email, phone, title, companyId } = req.body;

    if (!firstName || !lastName) {
      return res.status(400).json({ error: "firstName and lastName are required" });
    }

    const contactId = await createContactSimple({
      firstName,
      lastName,
      email: email || null,
      phone: phone || null,
      title: title || null,
      companyId: companyId || null,
      source: "vsto_addin",
      createdBy: req.user.userId,
    });

    res.status(201).json({
      success: true,
      contactId,
    });
  } catch (error) {
    console.error("[REST API] Create contact error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * POST /api/activities
 * Create new activity (email, call, meeting, note)
 */
router.post("/activities", authenticateJWT, async (req, res) => {
  try {
    const {
      type,
      subject,
      description,
      contactId,
      companyId,
      corporationId,
      dealId,
      scheduledAt,
      hasAttachment,
      attachmentCount,
    } = req.body;

    if (!type || !subject) {
      return res.status(400).json({ error: "type and subject are required" });
    }

    const activityId = await createActivity({
      type,
      subject,
      description: description || null,
      contactId: contactId || null,
      companyId: companyId || null,
      corporationId: corporationId || null,
      dealId: dealId || null,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : new Date(),
      hasAttachment: hasAttachment || false,
      attachmentCount: attachmentCount || 0,
      createdBy: req.user.userId,
    });

    res.status(201).json({
      success: true,
      activityId,
    });
  } catch (error) {
    console.error("[REST API] Create activity error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/companies/:id
 * Get company by ID
 */
router.get("/companies/:id", authenticateJWT, async (req, res) => {
  try {
    const { id } = req.params;

    const company = await getCompanyById(id);

    if (!company) {
      return res.status(404).json({ error: "Company not found" });
    }

    res.json({
      data: company,
    });
  } catch (error) {
    console.error("[REST API] Get company error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/corporations/:id
 * Get corporation by ID
 */
router.get("/corporations/:id", authenticateJWT, async (req, res) => {
  try {
    const { id } = req.params;

    const corporation = await getCorporationById(id);

    if (!corporation) {
      return res.status(404).json({ error: "Corporation not found" });
    }

    res.json({
      data: corporation,
    });
  } catch (error) {
    console.error("[REST API] Get corporation error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

console.log("[REST API] Middleware loaded");

export default router;

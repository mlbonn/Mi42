import axios, { AxiosInstance } from 'axios';
import { db } from './db';

interface SmarterMailConfig {
  host: string;
  port: number;
  username: string;
  password: string;
  useSSL: boolean;
}

interface EmailMessage {
  id: string;
  from: string;
  to: string;
  cc?: string;
  bcc?: string;
  subject: string;
  body: string;
  htmlBody?: string;
  date: Date;
  read: boolean;
  flagged: boolean;
  folder: string;
  attachments: Array<{
    filename: string;
    mimeType: string;
    size: number;
  }>;
}

class EmailService {
  private client: AxiosInstance;
  private config: SmarterMailConfig;
  private sessionId: string | null = null;

  constructor(config: SmarterMailConfig) {
    this.config = config;
    this.client = axios.create({
      baseURL: `https://${config.host}:${config.port}/api/v1`,
      https: { rejectUnauthorized: false },
      timeout: 30000,
    });
  }

  /**
   * Authenticate with SmarterMail
   */
  async authenticate(): Promise<void> {
    try {
      const response = await this.client.post('/authentication/login', {
        username: this.config.username,
        password: this.config.password,
      });

      this.sessionId = response.data.sessionId;
      this.client.defaults.headers.common['X-Session-ID'] = this.sessionId;
      console.log('[EmailService] Authenticated successfully');
    } catch (error) {
      console.error('[EmailService] Authentication failed:', error);
      throw new Error('Failed to authenticate with SmarterMail');
    }
  }

  /**
   * Fetch emails from a specific folder
   */
  async fetchEmails(folder: string = 'Inbox', limit: number = 50): Promise<EmailMessage[]> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      const response = await this.client.get(`/messages`, {
        params: {
          folder,
          limit,
          sortBy: 'date',
          sortOrder: 'desc',
        },
      });

      const emails: EmailMessage[] = response.data.messages.map((msg: any) => ({
        id: msg.uid,
        from: msg.from,
        to: msg.to,
        cc: msg.cc,
        bcc: msg.bcc,
        subject: msg.subject,
        body: msg.textBody || '',
        htmlBody: msg.htmlBody,
        date: new Date(msg.date),
        read: msg.seen,
        flagged: msg.flagged,
        folder,
        attachments: msg.attachments || [],
      }));

      return emails;
    } catch (error) {
      console.error(`[EmailService] Failed to fetch emails from ${folder}:`, error);
      throw error;
    }
  }

  /**
   * Get email by ID
   */
  async getEmail(messageId: string, folder: string): Promise<EmailMessage | null> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      const response = await this.client.get(`/messages/${messageId}`, {
        params: { folder },
      });

      const msg = response.data;
      return {
        id: msg.uid,
        from: msg.from,
        to: msg.to,
        cc: msg.cc,
        bcc: msg.bcc,
        subject: msg.subject,
        body: msg.textBody || '',
        htmlBody: msg.htmlBody,
        date: new Date(msg.date),
        read: msg.seen,
        flagged: msg.flagged,
        folder,
        attachments: msg.attachments || [],
      };
    } catch (error) {
      console.error(`[EmailService] Failed to fetch email ${messageId}:`, error);
      return null;
    }
  }

  /**
   * Send email
   */
  async sendEmail(
    to: string,
    subject: string,
    body: string,
    htmlBody?: string,
    cc?: string,
    bcc?: string,
    attachments?: Array<{ filename: string; content: Buffer }>
  ): Promise<string> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      const response = await this.client.post(`/messages/send`, {
        to,
        cc,
        bcc,
        subject,
        textBody: body,
        htmlBody,
        attachments: attachments || [],
      });

      return response.data.messageId;
    } catch (error) {
      console.error('[EmailService] Failed to send email:', error);
      throw error;
    }
  }

  /**
   * Move email to folder
   */
  async moveEmail(messageId: string, fromFolder: string, toFolder: string): Promise<void> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      await this.client.post(`/messages/${messageId}/move`, {
        sourceFolder: fromFolder,
        destinationFolder: toFolder,
      });

      console.log(`[EmailService] Moved email ${messageId} to ${toFolder}`);
    } catch (error) {
      console.error('[EmailService] Failed to move email:', error);
      throw error;
    }
  }

  /**
   * Delete email
   */
  async deleteEmail(messageId: string, folder: string): Promise<void> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      await this.client.delete(`/messages/${messageId}`, {
        params: { folder },
      });

      console.log(`[EmailService] Deleted email ${messageId}`);
    } catch (error) {
      console.error('[EmailService] Failed to delete email:', error);
      throw error;
    }
  }

  /**
   * Mark email as read/unread
   */
  async markAsRead(messageId: string, folder: string, read: boolean = true): Promise<void> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      await this.client.patch(`/messages/${messageId}`, {
        seen: read,
      });

      console.log(`[EmailService] Marked email ${messageId} as ${read ? 'read' : 'unread'}`);
    } catch (error) {
      console.error('[EmailService] Failed to mark email:', error);
      throw error;
    }
  }

  /**
   * Get folders
   */
  async getFolders(): Promise<string[]> {
    if (!this.sessionId) {
      await this.authenticate();
    }

    try {
      const response = await this.client.get(`/folders`);
      return response.data.folders;
    } catch (error) {
      console.error('[EmailService] Failed to fetch folders:', error);
      throw error;
    }
  }

  /**
   * Sync emails to database
   */
  async syncEmailsToDatabase(userId: string, accountId: string): Promise<void> {
    try {
      const folders = await this.getFolders();

      for (const folder of folders) {
        console.log(`[EmailService] Syncing folder: ${folder}`);
        const emails = await this.fetchEmails(folder, 100);

        for (const email of emails) {
          // Save to database
          await db.saveEmail({
            userId,
            accountId,
            messageId: email.id,
            from: email.from,
            to: email.to,
            cc: email.cc,
            bcc: email.bcc,
            subject: email.subject,
            body: email.body,
            htmlBody: email.htmlBody,
            date: email.date,
            read: email.read,
            flagged: email.flagged,
            folder: email.folder,
            attachmentCount: email.attachments.length,
          });
        }
      }

      console.log(`[EmailService] Sync completed for user ${userId}`);
    } catch (error) {
      console.error('[EmailService] Sync failed:', error);
      throw error;
    }
  }

  /**
   * Logout
   */
  async logout(): Promise<void> {
    if (this.sessionId) {
      try {
        await this.client.post('/authentication/logout');
        this.sessionId = null;
        console.log('[EmailService] Logged out successfully');
      } catch (error) {
        console.error('[EmailService] Logout failed:', error);
      }
    }
  }
}

export { EmailService, EmailMessage, SmarterMailConfig };

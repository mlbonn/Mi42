import { router, protectedProcedure } from './_core/trpc';
import { z } from 'zod';
import { EmailCacheService, SmarterMailConfig } from './emailCacheService';

// Mock email account - später von DB laden
async function getEmailAccount(userId: string) {
  // TODO: Load from database
  return {
    id: 'default',
    imapHost: 'mail.bl2020.com',
    imapPort: 993,
    imapUsername: 'FRIDAYarchiv@bl2020.com',
    imapPassword: 'encrypted_password', // Should be decrypted
    useSSL: true,
  };
}

// Decrypt password (simplified - use proper encryption in production)
function decryptPassword(encrypted: string): string {
  // TODO: Implement proper decryption
  return encrypted;
}

// Create email service instance
function createEmailService(account: any): EmailCacheService {
  return new EmailCacheService({
    host: account.imapHost,
    port: account.imapPort,
    username: account.imapUsername,
    password: decryptPassword(account.imapPassword),
    useSSL: account.useSSL || true,
  });
}

export const emailClientRouter = router({
  /**
   * Get emails from folder
   */
  getEmails: protectedProcedure
    .input(
      z.object({
        folder: z.string().default('Inbox'),
        limit: z.number().default(50),
        offset: z.number().default(0),
        search: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        const emails = await service.getEmails(input.folder, input.limit);
        await service.logout();

        // Filter by search query if provided
        if (input.search) {
          return emails.filter(
            (email) =>
              email.subject.toLowerCase().includes(input.search!.toLowerCase()) ||
              email.from.toLowerCase().includes(input.search!.toLowerCase())
          );
        }

        return emails;
      } catch (error) {
        console.error('[emailClientRouter] getEmails error:', error);
        throw error;
      }
    }),

  /**
   * Get single email
   */
  getEmail: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        folder: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        const email = await service.getEmail(input.messageId, input.folder);
        await service.logout();

        if (!email) {
          throw new Error('E-Mail nicht gefunden');
        }

        return email;
      } catch (error) {
        console.error('[emailClientRouter] getEmail error:', error);
        throw error;
      }
    }),

  /**
   * Get folders
   */
  getFolders: protectedProcedure.query(async ({ ctx }) => {
    try {
      const account = await getEmailAccount(ctx.user.id);
      const service = createEmailService(account);
      const folders = await service.getFolders();
      await service.logout();
      return folders;
    } catch (error) {
      console.error('[emailClientRouter] getFolders error:', error);
      throw error;
    }
  }),

  /**
   * Send email
   */
  sendEmail: protectedProcedure
    .input(
      z.object({
        to: z.string().email(),
        subject: z.string(),
        body: z.string(),
        htmlBody: z.string().optional(),
        cc: z.string().optional(),
        bcc: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);

        const messageId = await service.sendEmail(
          input.to,
          input.subject,
          input.body,
          input.htmlBody,
          input.cc,
          input.bcc
        );

        await service.logout();

        return { messageId, success: true };
      } catch (error) {
        console.error('[emailClientRouter] sendEmail error:', error);
        throw error;
      }
    }),

  /**
   * Move email to folder
   */
  moveEmail: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        fromFolder: z.string(),
        toFolder: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        await service.moveEmail(input.messageId, input.fromFolder, input.toFolder);
        await service.logout();

        return { success: true };
      } catch (error) {
        console.error('[emailClientRouter] moveEmail error:', error);
        throw error;
      }
    }),

  /**
   * Delete email
   */
  deleteEmail: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        folder: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        await service.deleteEmail(input.messageId, input.folder);
        await service.logout();

        return { success: true };
      } catch (error) {
        console.error('[emailClientRouter] deleteEmail error:', error);
        throw error;
      }
    }),

  /**
   * Mark email as read
   */
  markAsRead: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        folder: z.string(),
        read: z.boolean().default(true),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        await service.markAsRead(input.messageId, input.folder, input.read);
        await service.logout();

        return { success: true };
      } catch (error) {
        console.error('[emailClientRouter] markAsRead error:', error);
        throw error;
      }
    }),

  /**
   * Archive email to FRIDAY CRM
   * 
   * TODO: Speichert die E-Mail in der FRIDAY CRM Datenbank
   * mit Kontakt-Verlinkung und Anhängen
   */
  archiveEmail: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        folder: z.string(),
        contactId: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // TODO: Implement archiving to FRIDAY CRM database
        return { success: true, emailId: input.messageId };
      } catch (error) {
        console.error('[emailClientRouter] archiveEmail error:', error);
        throw error;
      }
    }),

  /**
   * Download attachment
   */
  downloadAttachment: protectedProcedure
    .input(
      z.object({
        messageId: z.string(),
        attachmentId: z.string(),
        folder: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const account = await getEmailAccount(ctx.user.id);
        const service = createEmailService(account);
        const attachmentData = await service.downloadAttachment(
          input.messageId,
          input.attachmentId,
          input.folder
        );
        await service.logout();

        // Return as base64 for download
        return {
          data: attachmentData.toString('base64'),
        };
      } catch (error) {
        console.error('[emailClientRouter] downloadAttachment error:', error);
        throw error;
      }
    }),
});

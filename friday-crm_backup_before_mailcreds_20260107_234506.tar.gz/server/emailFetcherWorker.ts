/**
 * Email Fetcher Worker
 * Periodically fetches emails from configured IMAP accounts and processes them
 * Supports parsing forwarded emails to extract original sender for archiving
 */

import Imap from 'imap';
import { simpleParser, ParsedMail } from 'mailparser';
import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { eq, and } from 'drizzle-orm';
import { emailAccounts, emailFetchLog, activities, contacts, contactEmails, attachments } from '../drizzle/schema';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { parseForwardedEmail, ParsedForwardedEmail } from './emailParser';

const pool = mysql.createPool(process.env.DATABASE_URL || '');
const db = drizzle(pool);

interface EmailAccount {
  id: string;
  name: string;
  email: string;
  purpose: string;
  imapHost: string;
  imapPort: number;
  imapUser: string;
  imapPassword: string;
  imapSsl: boolean;
  deleteAfterFetch: boolean;
  markAsReadAfterFetch: boolean;
  fetchIntervalMinutes: number;
  isActive: boolean;
}

// Track last fetch time for each account
const lastFetchTimes: Map<string, number> = new Map();

async function getActiveAccounts(): Promise<EmailAccount[]> {
  return await db.select().from(emailAccounts).where(eq(emailAccounts.isActive, true));
}

async function updateAccountStatus(accountId: string, error: string | null, lastFetchAt: Date) {
  await db.update(emailAccounts).set({
    lastFetchAt,
    lastError: error,
  }).where(eq(emailAccounts.id, accountId));
}

async function findContactByEmail(email: string): Promise<{ id: string; firstName: string | null; lastName: string | null } | null> {
  if (!email) return null;
  
  const normalizedEmail = email.toLowerCase().trim();
  
  // First check main contacts table
  const [contact] = await db.select({
    id: contacts.id,
    firstName: contacts.firstName,
    lastName: contacts.lastName,
  }).from(contacts).where(eq(contacts.email, normalizedEmail)).limit(1);
  
  if (contact) return contact;
  
  // Check contact_emails table
  const [contactEmail] = await db.select({
    contactId: contactEmails.contactId,
  }).from(contactEmails).where(eq(contactEmails.email, normalizedEmail)).limit(1);
  
  if (contactEmail) {
    const [foundContact] = await db.select({
      id: contacts.id,
      firstName: contacts.firstName,
      lastName: contacts.lastName,
    }).from(contacts).where(eq(contacts.id, contactEmail.contactId)).limit(1);
    return foundContact || null;
  }
  
  return null;
}

async function createActivityFromEmail(
  accountId: string,
  email: ParsedMail,
  contact: { id: string; firstName: string | null; lastName: string | null } | null,
  purpose: string,
  forwardedInfo?: ParsedForwardedEmail
): Promise<string> {
  const activityId = crypto.randomUUID();
  
  // Determine activity type based on purpose
  let activityType = 'Email';
  let subject = email.subject || 'Kein Betreff';
  
  // Remove forward prefixes from subject for cleaner display
  const cleanSubject = subject.replace(/^(Fwd?:|WG:|Wtr:|Weitergeleitet:)\s*/i, '').trim();
  
  if (purpose === 'archive') {
    activityType = 'Email Archive';
    if (forwardedInfo?.isForwarded) {
      // Use original subject if available, otherwise cleaned subject
      subject = `📧 ${forwardedInfo.originalSubject || cleanSubject}`;
    } else {
      subject = `📧 ${cleanSubject}`;
    }
  } else if (purpose === 'bounces') {
    activityType = 'Bounce';
    subject = `⚠️ Bounce: ${cleanSubject}`;
  } else if (purpose === 'replies') {
    activityType = 'Email Reply';
    subject = `↩️ Antwort: ${cleanSubject}`;
  }
  
  // Build content with forwarding info if available
  let content = email.text || email.html || '';
  
  if (forwardedInfo?.isForwarded && forwardedInfo.originalSenderEmail) {
    const header = `--- Archivierte E-Mail ---
Ursprünglicher Absender: ${forwardedInfo.originalSenderName ? `${forwardedInfo.originalSenderName} <${forwardedInfo.originalSenderEmail}>` : forwardedInfo.originalSenderEmail}
${forwardedInfo.originalDate ? `Ursprüngliches Datum: ${forwardedInfo.originalDate}` : ''}
${forwardedInfo.originalSubject ? `Ursprünglicher Betreff: ${forwardedInfo.originalSubject}` : ''}
---

`;
    content = header + content;
  }
  
  await db.insert(activities).values({
    id: activityId,
    contactId: contact?.id || null,
    activityType,
    activityDate: email.date || new Date(),
    subject,
    content,
    direction: 'Inbound',
    emailMessageId: email.messageId || null,
    hasAttachment: (email.attachments?.length || 0) > 0,
    attachmentCount: email.attachments?.length || 0,
  });
  
  // Save attachments if any
  if (email.attachments && email.attachments.length > 0) {
    const uploadsDir = path.join(process.cwd(), 'uploads', 'email-attachments');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    
    for (const attachment of email.attachments) {
      const attachmentId = crypto.randomUUID();
      const fileName = `${attachmentId}-${attachment.filename || 'attachment'}`;
      const filePath = path.join(uploadsDir, fileName);
      
      fs.writeFileSync(filePath, attachment.content);
      
      await db.insert(attachments).values({
        id: attachmentId,
        activityId,
        fileName,
        originalFileName: attachment.filename || 'attachment',
        filePath: `uploads/email-attachments/${fileName}`,
        fileSize: attachment.size || 0,
        mimeType: attachment.contentType || 'application/octet-stream',
      });
    }
  }
  
  return activityId;
}

async function logEmailFetch(data: {
  emailAccountId: string;
  messageId?: string;
  fromAddress?: string;
  toAddress?: string;
  subject?: string;
  status: string;
  matchedContactId?: string;
  activityId?: string;
  errorMessage?: string;
}) {
  await db.insert(emailFetchLog).values({
    id: crypto.randomUUID(),
    ...data,
  });
}

function fetchEmails(account: EmailAccount): Promise<void> {
  return new Promise((resolve, reject) => {
    const imap = new Imap({
      user: account.imapUser,
      password: account.imapPassword,
      host: account.imapHost,
      port: account.imapPort,
      tls: account.imapSsl,
      tlsOptions: { rejectUnauthorized: false },
      connTimeout: 30000,
      authTimeout: 30000,
    });

    let processedCount = 0;
    let errorCount = 0;

    imap.once('ready', () => {
      imap.openBox('INBOX', false, async (err, box) => {
        if (err) {
          console.error(`[EmailFetcher] Error opening INBOX for ${account.email}:`, err);
          imap.end();
          reject(err);
          return;
        }

        if (box.messages.total === 0) {
          console.log(`[EmailFetcher] No messages in ${account.email}`);
          imap.end();
          resolve();
          return;
        }

        // Fetch all unseen messages
        const searchCriteria = ['UNSEEN'];
        
        imap.search(searchCriteria, (searchErr, uids) => {
          if (searchErr) {
            console.error(`[EmailFetcher] Search error for ${account.email}:`, searchErr);
            imap.end();
            reject(searchErr);
            return;
          }

          if (!uids || uids.length === 0) {
            console.log(`[EmailFetcher] No new messages in ${account.email}`);
            imap.end();
            resolve();
            return;
          }

          console.log(`[EmailFetcher] Found ${uids.length} new messages in ${account.email}`);

          const fetch = imap.fetch(uids, { bodies: '', struct: true });
          const messagesToDelete: number[] = [];

          fetch.on('message', (msg, seqno) => {
            let buffer = '';

            msg.on('body', (stream) => {
              stream.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
              });
            });

            msg.once('end', async () => {
              try {
                const parsed = await simpleParser(buffer);
                
                // Get the direct sender (who forwarded the email)
                const directSenderEmail = parsed.from?.value?.[0]?.address || '';
                
                // For archive purpose, try to extract original sender from forwarded email
                let targetEmail = directSenderEmail;
                let forwardedInfo: ParsedForwardedEmail | undefined;
                
                if (account.purpose === 'archive') {
                  console.log(`[EmailFetcher] Checking for forwarded email content...`);
                  
                  // Parse the email body to find original sender
                  const emailBody = parsed.text || parsed.html || '';
                  forwardedInfo = await parseForwardedEmail(emailBody, parsed.subject);
                  
                  if (forwardedInfo.isForwarded && forwardedInfo.originalSenderEmail) {
                    console.log(`[EmailFetcher] Forwarded email detected! Original sender: ${forwardedInfo.originalSenderEmail}`);
                    targetEmail = forwardedInfo.originalSenderEmail;
                  } else if (forwardedInfo.isForwarded) {
                    console.log(`[EmailFetcher] Forwarded email detected but could not extract original sender`);
                  }
                }
                
                // Find matching contact using the target email (original sender for forwards)
                const contact = await findContactByEmail(targetEmail);
                
                if (contact) {
                  console.log(`[EmailFetcher] Matched contact: ${contact.firstName} ${contact.lastName} (${targetEmail})`);
                } else {
                  console.log(`[EmailFetcher] No matching contact found for: ${targetEmail}`);
                }
                
                // Create activity
                const activityId = await createActivityFromEmail(
                  account.id,
                  parsed,
                  contact,
                  account.purpose,
                  forwardedInfo
                );
                
                // Log successful fetch
                await logEmailFetch({
                  emailAccountId: account.id,
                  messageId: parsed.messageId || undefined,
                  fromAddress: forwardedInfo?.originalSenderEmail || directSenderEmail,
                  toAddress: parsed.to?.value?.[0]?.address,
                  subject: forwardedInfo?.originalSubject || parsed.subject,
                  status: forwardedInfo?.isForwarded ? 'processed_forwarded' : 'processed',
                  matchedContactId: contact?.id,
                  activityId,
                });
                
                processedCount++;
                
                if (account.deleteAfterFetch) {
                  messagesToDelete.push(seqno);
                }
                
                const statusMsg = forwardedInfo?.isForwarded 
                  ? `(forwarded from ${forwardedInfo.originalSenderEmail})`
                  : '';
                console.log(`[EmailFetcher] Processed email from ${targetEmail} ${statusMsg}: ${parsed.subject}`);
              } catch (parseErr: any) {
                console.error(`[EmailFetcher] Error parsing message:`, parseErr);
                errorCount++;
                
                await logEmailFetch({
                  emailAccountId: account.id,
                  status: 'error',
                  errorMessage: parseErr.message,
                });
              }
            });
          });

          fetch.once('error', (fetchErr) => {
            console.error(`[EmailFetcher] Fetch error:`, fetchErr);
            reject(fetchErr);
          });

          fetch.once('end', () => {
            // Mark as read if configured
            if (account.markAsReadAfterFetch && uids.length > 0) {
              imap.addFlags(uids, ['\\Seen'], (flagErr) => {
                if (flagErr) console.error(`[EmailFetcher] Error marking as read:`, flagErr);
              });
            }
            
            // Delete messages if configured
            if (account.deleteAfterFetch && messagesToDelete.length > 0) {
              imap.addFlags(uids, ['\\Deleted'], (delErr) => {
                if (delErr) {
                  console.error(`[EmailFetcher] Error deleting messages:`, delErr);
                } else {
                  imap.expunge((expErr) => {
                    if (expErr) console.error(`[EmailFetcher] Error expunging:`, expErr);
                    else console.log(`[EmailFetcher] Deleted ${messagesToDelete.length} messages`);
                  });
                }
              });
            }
            
            console.log(`[EmailFetcher] Finished processing ${account.email}: ${processedCount} processed, ${errorCount} errors`);
            imap.end();
          });
        });
      });
    });

    imap.once('error', (err: any) => {
      console.error(`[EmailFetcher] IMAP error for ${account.email}:`, err);
      reject(err);
    });

    imap.once('end', () => {
      resolve();
    });

    imap.connect();
  });
}

async function processAccount(account: EmailAccount) {
  console.log(`[EmailFetcher] Processing account: ${account.name} (${account.email})`);
  
  try {
    await fetchEmails(account);
    await updateAccountStatus(account.id, null, new Date());
  } catch (error: any) {
    console.error(`[EmailFetcher] Error processing ${account.email}:`, error);
    await updateAccountStatus(account.id, error.message, new Date());
  }
}

async function runFetchCycle() {
  console.log('[EmailFetcher] Starting fetch cycle...');
  
  const accounts = await getActiveAccounts();
  console.log(`[EmailFetcher] Found ${accounts.length} active accounts`);
  
  const now = Date.now();
  
  for (const account of accounts) {
    const lastFetch = lastFetchTimes.get(account.id) || 0;
    const intervalMs = account.fetchIntervalMinutes * 60 * 1000;
    
    if (now - lastFetch >= intervalMs) {
      await processAccount(account);
      lastFetchTimes.set(account.id, now);
    } else {
      console.log(`[EmailFetcher] Skipping ${account.email} - not due yet`);
    }
  }
}

// Main loop
async function main() {
  console.log('[EmailFetcher] Worker started');
  console.log('[EmailFetcher] Forwarded email parsing enabled with LLM support');
  
  // Run immediately on start
  await runFetchCycle();
  
  // Then run every minute to check for due accounts
  setInterval(async () => {
    try {
      await runFetchCycle();
    } catch (error) {
      console.error('[EmailFetcher] Error in fetch cycle:', error);
    }
  }, 60 * 1000); // Check every minute
}

main().catch(console.error);

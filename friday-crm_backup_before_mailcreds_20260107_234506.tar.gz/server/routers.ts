import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { simpleAuthRouter } from "./simpleAuthRouter";
import { userRouter } from "./userRouter";
import { contactsRouter } from "./contactsRouter";
import { companiesRouter } from "./companiesRouter";
import { corporationsRouter } from "./corporationsRouter";
import { dealsRouter } from "./dealsRouter";
import { activitiesRouter } from "./activitiesRouter";
import { jwtAuthRouter } from "./jwtAuthRouter";
import { dashboardRouter } from "./dashboardRouter";
import { emailsRouter } from "./emailsRouter";
import { contactAddressesRouter } from "./contactAddressesRouter";
import { contactPhonesRouter } from "./contactPhonesRouter";
import { distributionListsRouter } from "./distributionListsRouter";
import { searchRouter } from "./searchRouter";
import { calendarRouter } from "./calendarRouter";
import { scoutRouter } from "./scoutRouter";
import { settingsRouter } from "./settingsRouter";
import { emailAccountsRouter } from "./emailAccountsRouter";
import { projectRouter } from "./projectRouter";
import { emailContactSearchRouter } from "./emailContactSearchRouter";
import { emailClientRouter } from "./emailClientRouter";

export const appRouter = router({
  system: systemRouter,
  auth: simpleAuthRouter,
  users: userRouter,
  contacts: contactsRouter,
  companies: companiesRouter,
  corporations: corporationsRouter,
  deals: dealsRouter,
  activities: activitiesRouter,
  jwtAuth: jwtAuthRouter,
  dashboard: dashboardRouter,
  emails: emailsRouter,
  contactAddresses: contactAddressesRouter,
  contactPhones: contactPhonesRouter,
  distributionLists: distributionListsRouter,
  search: searchRouter,
  calendar: calendarRouter,
  scout: scoutRouter,
  settings: settingsRouter,
  emailAccounts: emailAccountsRouter,
  projects: projectRouter,
  emailSearch: emailContactSearchRouter,
  emailClient: emailClientRouter,
});

export type AppRouter = typeof appRouter;

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Mail, Send, Trash2, Archive, Search, Plus, ChevronLeft, Flag } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface EmailMessage {
  id: string;
  from: string;
  to: string;
  cc?: string;
  bcc?: string;
  subject: string;
  body: string;
  htmlBody?: string;
  date: Date;
  read: boolean;
  flagged: boolean;
  folder: string;
  attachments: Array<{
    id: string;
    filename: string;
    mimeType: string;
    size: number;
  }>;
}

const FOLDERS = ['Inbox', 'Drafts', 'Sent', 'Trash', 'Spam'];

export default function EmailClient() {
  const [currentFolder, setCurrentFolder] = useState<string>('Inbox');
  const [selectedEmail, setSelectedEmail] = useState<EmailMessage | null>(null);
  const [emails, setEmails] = useState<EmailMessage[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showCompose, setShowCompose] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch emails
  const { data: fetchedEmails, isLoading } = trpc.email.getEmails.useQuery({
    folder: currentFolder,
    limit: 50,
    search: searchQuery,
  });

  useEffect(() => {
    if (fetchedEmails) {
      setEmails(fetchedEmails);
    }
  }, [fetchedEmails]);

  // Mutations
  const markAsReadMutation = trpc.email.markAsRead.useMutation();
  const deleteEmailMutation = trpc.email.deleteEmail.useMutation();
  const moveEmailMutation = trpc.email.moveEmail.useMutation();
  const archiveEmailMutation = trpc.email.archiveEmail.useMutation();

  const handleSelectEmail = async (email: EmailMessage) => {
    setSelectedEmail(email);
    
    // Mark as read
    if (!email.read) {
      await markAsReadMutation.mutateAsync({
        messageId: email.id,
        folder: currentFolder,
        read: true,
      });
    }
  };

  const handleDelete = async (email: EmailMessage) => {
    await deleteEmailMutation.mutateAsync({
      messageId: email.id,
      folder: currentFolder,
    });
    setEmails(emails.filter(e => e.id !== email.id));
    setSelectedEmail(null);
  };

  const handleMove = async (email: EmailMessage, toFolder: string) => {
    await moveEmailMutation.mutateAsync({
      messageId: email.id,
      fromFolder: currentFolder,
      toFolder,
    });
    setEmails(emails.filter(e => e.id !== email.id));
    setSelectedEmail(null);
  };

  const handleArchive = async (email: EmailMessage) => {
    setLoading(true);
    try {
      await archiveEmailMutation.mutateAsync({
        messageId: email.id,
        folder: currentFolder,
      });
      setEmails(emails.filter(e => e.id !== email.id));
      setSelectedEmail(null);
    } finally {
      setLoading(false);
    }
  };

  const filteredEmails = emails.filter(email =>
    email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.from.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Mail className="w-6 h-6" />
              E-Mails
            </h1>
            <Button onClick={() => setShowCompose(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Neue E-Mail
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
            <Input
              placeholder="E-Mails durchsuchen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Folders */}
        <div className="w-48 bg-white border-r p-4 overflow-y-auto">
          <div className="space-y-2">
            {FOLDERS.map((folder) => (
              <button
                key={folder}
                onClick={() => {
                  setCurrentFolder(folder);
                  setSelectedEmail(null);
                }}
                className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                  currentFolder === folder
                    ? 'bg-blue-100 text-blue-900 font-semibold'
                    : 'hover:bg-gray-100'
                }`}
              >
                {folder}
              </button>
            ))}
          </div>
        </div>

        {/* Email List & Reader */}
        <div className="flex-1 flex overflow-hidden">
          {/* Email List */}
          <div className="w-96 border-r bg-white overflow-y-auto">
            {isLoading ? (
              <div className="p-4 text-center text-gray-500">Lädt...</div>
            ) : filteredEmails.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                Keine E-Mails in {currentFolder}
              </div>
            ) : (
              <div className="divide-y">
                {filteredEmails.map((email) => (
                  <button
                    key={email.id}
                    onClick={() => handleSelectEmail(email)}
                    className={`w-full text-left p-4 border-l-4 transition-colors ${
                      selectedEmail?.id === email.id
                        ? 'bg-blue-50 border-l-blue-500'
                        : 'border-l-transparent hover:bg-gray-50'
                    } ${!email.read ? 'font-semibold' : ''}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{email.from}</div>
                        <div className="text-sm text-gray-600 truncate">
                          {email.subject}
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          {new Date(email.date).toLocaleDateString('de-DE')}
                        </div>
                      </div>
                      {email.flagged && (
                        <Flag className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Email Reader */}
          <div className="flex-1 bg-white overflow-y-auto">
            {selectedEmail ? (
              <div className="p-6">
                {/* Email Header */}
                <div className="mb-6 pb-6 border-b">
                  <button
                    onClick={() => setSelectedEmail(null)}
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Zurück
                  </button>

                  <h2 className="text-2xl font-bold mb-4">{selectedEmail.subject}</h2>

                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="font-semibold">Von:</span> {selectedEmail.from}
                    </div>
                    <div>
                      <span className="font-semibold">An:</span> {selectedEmail.to}
                    </div>
                    {selectedEmail.cc && (
                      <div>
                        <span className="font-semibold">Cc:</span> {selectedEmail.cc}
                      </div>
                    )}
                    <div className="text-gray-500">
                      {new Date(selectedEmail.date).toLocaleString('de-DE')}
                    </div>
                  </div>
                </div>

                {/* Email Body */}
                <div className="mb-6">
                  {selectedEmail.htmlBody ? (
                    <div
                      dangerouslySetInnerHTML={{ __html: selectedEmail.htmlBody }}
                      className="prose prose-sm max-w-none"
                    />
                  ) : (
                    <div className="whitespace-pre-wrap text-gray-700">
                      {selectedEmail.body}
                    </div>
                  )}
                </div>

                {/* Attachments */}
                {selectedEmail.attachments.length > 0 && (
                  <div className="mb-6 pb-6 border-t">
                    <h3 className="font-semibold mb-3">Anhänge ({selectedEmail.attachments.length})</h3>
                    <div className="space-y-2">
                      {selectedEmail.attachments.map((att) => (
                        <div key={att.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div>
                            <div className="font-medium text-sm">{att.filename}</div>
                            <div className="text-xs text-gray-500">
                              {(att.size / 1024).toFixed(2)} KB
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleArchive(selectedEmail)}
                    disabled={loading}
                    className="gap-2"
                  >
                    <Archive className="w-4 h-4" />
                    Archivieren
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(selectedEmail)}
                    className="gap-2 text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                    Löschen
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                <div className="text-center">
                  <Mail className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Wählen Sie eine E-Mail, um sie zu lesen</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Compose Dialog */}
      {showCompose && (
        <ComposeDialog onClose={() => setShowCompose(false)} />
      )}
    </div>
  );
}

/**
 * Compose Dialog Component
 */
function ComposeDialog({ onClose }: { onClose: () => void }) {
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);

  const sendEmailMutation = trpc.email.sendEmail.useMutation();

  const handleSend = async () => {
    setSending(true);
    try {
      await sendEmailMutation.mutateAsync({
        to,
        subject,
        body,
      });
      onClose();
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Neue E-Mail
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>An</Label>
            <Input
              type="email"
              placeholder="empfaenger@example.com"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </div>

          <div>
            <Label>Betreff</Label>
            <Input
              placeholder="E-Mail Betreff"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div>
            <Label>Nachricht</Label>
            <textarea
              placeholder="Schreiben Sie Ihre E-Mail..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full h-64 p-3 border rounded-lg font-mono text-sm"
            />
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>
              Abbrechen
            </Button>
            <Button onClick={handleSend} disabled={sending || !to || !subject || !body}>
              {sending ? 'Wird gesendet...' : 'Senden'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

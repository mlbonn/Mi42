import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, Plus, Trash2, Save } from 'lucide-react';

export default function Emails() {
  const [projects, setProjects] = useState<Array<{ id: string; name: string; emailCount: number }>>([
    { id: '1', name: 'Projekt A', emailCount: 5 },
    { id: '2', name: 'Projekt B', emailCount: 3 },
  ]);

  const [selectedProject, setSelectedProject] = useState<string | null>(null);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">📧 E-Mails & Projekte</h1>
        <p className="text-gray-600">Verwalten Sie Ihre E-Mails und verlinken Sie sie mit Projekten</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Projekte */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Projekte
              </CardTitle>
              <CardDescription>Wählen Sie ein Projekt</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {projects.map((project) => (
                <button
                  key={project.id}
                  onClick={() => setSelectedProject(project.id)}
                  className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                    selectedProject === project.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold">{project.name}</div>
                  <div className="text-sm text-gray-500">{project.emailCount} E-Mails</div>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* E-Mail Details */}
        <div className="lg:col-span-2">
          {selectedProject ? (
            <Card>
              <CardHeader>
                <CardTitle>
                  {projects.find((p) => p.id === selectedProject)?.name}
                </CardTitle>
                <CardDescription>E-Mail-Verwaltung und Projekt-Integration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Zeit-Planung</Label>
                  <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-semibold">120h / 150h</span>
                      <span className="text-sm text-gray-600">80%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: '80%' }}></div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Kosten-Planung</Label>
                  <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-semibold">€8.500 / €10.000</span>
                      <span className="text-sm text-gray-600">85%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button className="flex-1">
                    <Plus className="w-4 h-4 mr-2" />
                    E-Mail verlinken
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Speichern
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6 text-center text-gray-500">
                <Mail className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>Wählen Sie ein Projekt, um E-Mails zu verwalten</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

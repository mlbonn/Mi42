import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { trpc } from '@/lib/trpc';
import { Eye, EyeOff, Save, Key, RefreshCw, Settings as SettingsIcon, Brain, Zap, CheckCircle2, XCircle, Loader2, Mail } from 'lucide-react';
import EmailSettings from '@/components/EmailSettings';

export default function Settings() {
  const utils = trpc.useUtils();
  
  // API Keys State
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  const [testResults, setTestResults] = useState<Record<string, 'success' | 'error' | 'testing' | null>>({});

  // Scout Settings State
  const [scoutSettings, setScoutSettings] = useState({
    minRevenueMio: 100,
    minEmployees: 500,
    companyTypes: ['Manufacturer'],
    targetMarkets: ['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'],
  });

  const { data: savedKeys, isLoading } = trpc.settings.getApiKeys.useQuery();
  const { data: savedScoutSettings } = trpc.settings.getScoutSettings.useQuery();
  
  const saveKeysMutation = trpc.settings.saveApiKeys.useMutation({
    onSuccess: () => {
      utils.settings.getApiKeys.invalidate();
      alert('API Keys gespeichert!');
    },
  });

  const testKeyMutation = trpc.settings.testApiKey.useMutation();

  const toggleKeyVisibility = (keyName: string) => {
    setShowKeys(prev => ({ ...prev, [keyName]: !prev[keyName] }));
  };

  const handleSave = () => {
    saveKeysMutation.mutate(apiKeys);
  };

  const saveScoutSettingsMutation = trpc.settings.saveScoutSettings.useMutation({
    onSuccess: () => {
      utils.settings.getScoutSettings.invalidate();
      alert('Scout Agent Filter gespeichert!');
    },
  });

  const handleSaveScoutSettings = () => {
    saveScoutSettingsMutation.mutate(scoutSettings);
  };

  // Load saved keys
  useEffect(() => {
    if (savedKeys) {
      setApiKeys(savedKeys as Record<string, string>);
    }
  }, [savedKeys]);

  // Load saved scout settings
  useEffect(() => {
    if (savedScoutSettings) {
      setScoutSettings({
        minRevenueMio: savedScoutSettings.minRevenueMio || 100,
        minEmployees: savedScoutSettings.minEmployees || 500,
        companyTypes: savedScoutSettings.companyTypes || ['Manufacturer'],
        targetMarkets: savedScoutSettings.targetMarkets || ['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'],
      });
    }
  }, [savedScoutSettings]);

  const handleTestKey = async (service: string) => {
    let keyValue = apiKeys[service] || (savedKeys as Record<string, string>)?.[service];
    if (!keyValue) return;
    
    // For Ollama, combine key and URL
    if (service === 'ollama') {
      const urlValue = apiKeys.ollama_url || (savedKeys as Record<string, string>)?.ollama_url;
      keyValue = `${keyValue}|||${urlValue || ''}`;
    }
    
    setTestResults(prev => ({ ...prev, [service]: 'testing' }));
    try {
      const result = await testKeyMutation.mutateAsync({ service, key: keyValue });
      setTestResults(prev => ({ ...prev, [service]: result.success ? 'success' : 'error' }));
      if (!result.success) {
        alert(`❌ ${service} Key ungültig: ${result.error}`);
      } else if (service === 'ollama') {
        alert('✅ Ollama Verbindung erfolgreich!');
      }
    } catch (error) {
      setTestResults(prev => ({ ...prev, [service]: 'error' }));
    }
  };

  // LLM Provider Configurations
  const llmConfigs = [
    {
      id: 'openai',
      name: 'OpenAI',
      description: 'GPT-4, GPT-3.5 für E-Mail-Generierung und Analyse',
      placeholder: 'sk-...',
      docs: 'https://platform.openai.com/api-keys',
      icon: '🤖',
    },
    {
      id: 'anthropic',
      name: 'Anthropic Claude',
      description: 'Claude 3 für komplexe Analysen und Texterstellung',
      placeholder: 'sk-ant-...',
      docs: 'https://console.anthropic.com/settings/keys',
      icon: '🧠',
    },
    {
      id: 'google',
      name: 'Google Gemini',
      description: 'Gemini Pro für multimodale Aufgaben',
      placeholder: 'AIza...',
      docs: 'https://aistudio.google.com/app/apikey',
      icon: '✨',
    },
    {
      id: 'mistral',
      name: 'Mistral AI',
      description: 'Mistral für schnelle, effiziente Verarbeitung',
      placeholder: 'mistral-...',
      docs: 'https://console.mistral.ai/api-keys/',
      icon: '🌬️',
    },
    {
      id: 'groq',
      name: 'Groq',
      description: 'Ultra-schnelle Inferenz mit LPU',
      placeholder: 'gsk_...',
      docs: 'https://console.groq.com/keys',
      icon: '⚡',
    },
    {
      id: 'ollama',
      name: 'Ollama (Self-hosted)',
      description: 'Selbst gehostetes LLM via OpenAI-kompatible API',
      placeholder: 'sk-...',
      docs: 'https://github.com/ollama/ollama/blob/main/docs/openai.md',
      icon: '🦙',
      hasCustomUrl: true,
    },
  ];

  // Lead Generation API Configurations
  const leadGenConfigs = [
    {
      id: 'apollo',
      name: 'Apollo.io',
      description: 'Kontakt-Suche und E-Mail-Finder',
      placeholder: 'apollo_...',
      docs: 'https://apolloio.github.io/apollo-api-docs/',
    },
    {
      id: 'linkedin',
      name: 'LinkedIn Sales Navigator',
      description: 'Konzern-Discovery und Kontakt-Anreicherung',
      placeholder: 'linkedin_...',
      docs: 'https://docs.microsoft.com/en-us/linkedin/',
    },
    {
      id: 'hunter',
      name: 'Hunter.io',
      description: 'E-Mail-Finder und Domain-Suche',
      placeholder: 'hunter_...',
      docs: 'https://hunter.io/api-documentation',
    },
    {
      id: 'zerobounce',
      name: 'ZeroBounce',
      description: 'E-Mail-Validierung',
      placeholder: 'zerobounce_...',
      docs: 'https://www.zerobounce.net/docs/',
    },
  ];

  const getTestIcon = (service: string) => {
    const status = testResults[service];
    if (status === 'testing') return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
    if (status === 'success') return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    if (status === 'error') return <XCircle className="h-4 w-4 text-red-500" />;
    return null;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Einstellungen</h1>
        <p className="text-gray-600">Verwalte API-Keys und System-Konfiguration</p>
      </div>

      <Tabs defaultValue="llm-keys" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="llm-keys">
            <Brain className="mr-2 h-4 w-4" />
            LLM Provider
          </TabsTrigger>
          <TabsTrigger value="lead-gen">
            <Key className="mr-2 h-4 w-4" />
            Lead Generation
          </TabsTrigger>
          <TabsTrigger value="scout-agent">
            <SettingsIcon className="mr-2 h-4 w-4" />
            Scout Agent
          </TabsTrigger>
          <TabsTrigger value="smtp">
            <RefreshCw className="mr-2 h-4 w-4" />
            SMTP / E-Mail
          </TabsTrigger>
          <TabsTrigger value="email-accounts">
            <Mail className="mr-2 h-4 w-4" />
            E-Mail-Konten
          </TabsTrigger>
        </TabsList>

        {/* LLM Provider Tab */}
        <TabsContent value="llm-keys" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                LLM Provider API Keys
              </CardTitle>
              <CardDescription className="mb-4">
                🤖 KI-Schnittstellen: Hier hinterlegst du API-Keys für Large Language Models (LLMs). Diese werden benötigt für: E-Mail-Texte generieren, Firmenprofile analysieren, Wettbewerber identifizieren, Kontaktdaten anreichern.
                Du kannst mehrere Provider konfigurieren und einen Standard-Provider wählen.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Default Provider Selection */}
              <div className="bg-gray-50 p-4 rounded-lg border">
                <Label className="text-base font-semibold mb-2 block">Standard LLM Provider</Label>
                <p className="text-sm text-gray-600 mb-3">
                  Wähle den Provider, der standardmäßig für alle AI-Funktionen verwendet wird
                </p>
                <Select
                  value={apiKeys.defaultLlmProvider || 'openai'}
                  onValueChange={(value) => setApiKeys({ ...apiKeys, defaultLlmProvider: value })}
                >
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="Provider wählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {llmConfigs.map((config) => (
                      <SelectItem key={config.id} value={config.id}>
                        <span className="flex items-center gap-2">
                          <span>{config.icon}</span>
                          <span>{config.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* LLM API Keys */}
              {llmConfigs.map((config) => (
                <div key={config.id} className="border-b pb-6 last:border-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{config.icon}</span>
                      <div>
                        <Label htmlFor={config.id} className="text-base font-semibold">
                          {config.name}
                        </Label>
                        <p className="text-sm text-gray-600 mt-1">{config.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getTestIcon(config.id)}
                      <a
                        href={config.docs}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline"
                      >
                        Docs →
                      </a>
                    </div>
                  </div>
                  {/* Ollama URL field */}
                  {(config as any).hasCustomUrl && (
                    <div className="mt-3">
                      <Label htmlFor={`${config.id}_url`} className="text-sm font-medium">
                        API URL
                      </Label>
                      <Input
                        id={`${config.id}_url`}
                        type="text"
                        value={apiKeys[`${config.id}_url`] || ''}
                        onChange={(e) => setApiKeys({ ...apiKeys, [`${config.id}_url`]: e.target.value })}
                        placeholder="https://your-ollama-server.com/api/chat/completions"
                        className="font-mono text-sm mt-1"
                      />
                      <p className="text-xs text-gray-500 mt-1">OpenAI-kompatible API URL (z.B. /api/chat/completions)</p>
                    </div>
                  )}
                  <div className="flex gap-2 mt-3">
                    <div className="relative flex-1">
                      <Input
                        id={config.id}
                        type={showKeys[config.id] ? 'text' : 'password'}
                        value={apiKeys[config.id] || ''}
                        onChange={(e) => setApiKeys({ ...apiKeys, [config.id]: e.target.value })}
                        placeholder={config.placeholder}
                        className="pr-10 font-mono text-sm"
                      />
                      <button
                        type="button"
                        onClick={() => toggleKeyVisibility(config.id)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showKeys[config.id] ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleTestKey(config.id)}
                      disabled={!apiKeys[config.id] && !(savedKeys as Record<string, string>)?.[config.id]}
                    >
                      Test
                    </Button>
                  </div>
                </div>
              ))}

              <div className="flex justify-end pt-4">
                <Button onClick={handleSave} disabled={saveKeysMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  {saveKeysMutation.isPending ? 'Speichere...' : 'Alle Keys speichern'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Lead Generation Tab */}
        <TabsContent value="lead-gen" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Lead Generation API Keys
              </CardTitle>
              <CardDescription className="mb-4">
                🎯 Datenquellen für Lead-Generierung: API-Keys für externe Dienste wie Hunter.io, Apollo.io, LinkedIn. Diese ermöglichen: E-Mail-Adressen von Ansprechpartnern finden, Firmendaten anreichern, Kontaktinformationen verifizieren.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {leadGenConfigs.map((config) => (
                <div key={config.id} className="border-b pb-6 last:border-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <Label htmlFor={config.id} className="text-base font-semibold">
                        {config.name}
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">{config.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {getTestIcon(config.id)}
                      <a
                        href={config.docs}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline"
                      >
                        Docs →
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <div className="relative flex-1">
                      <Input
                        id={config.id}
                        type={showKeys[config.id] ? 'text' : 'password'}
                        value={apiKeys[config.id] || ''}
                        onChange={(e) => setApiKeys({ ...apiKeys, [config.id]: e.target.value })}
                        placeholder={config.placeholder}
                        className="pr-10 font-mono text-sm"
                      />
                      <button
                        type="button"
                        onClick={() => toggleKeyVisibility(config.id)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showKeys[config.id] ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleTestKey(config.id)}
                      disabled={!apiKeys[config.id] && !(savedKeys as Record<string, string>)?.[config.id]}
                    >
                      Test
                    </Button>
                  </div>
                </div>
              ))}

              <div className="flex justify-end pt-4">
                <Button onClick={handleSave} disabled={saveKeysMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  {saveKeysMutation.isPending ? 'Speichere...' : 'Alle Keys speichern'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Scout Agent Tab */}
        <TabsContent value="scout-agent" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scout Agent Filter-Einstellungen</CardTitle>
              <CardDescription className="mb-4">
                🔍 Automatische Firmensuche: Der Scout Agent findet selbstständig neue Zielunternehmen. Hier definierst du Filterkriterien wie: Mindest-Umsatz, Mitarbeiterzahl, Regionen, Branchen. Nur Firmen die diese Kriterien erfüllen werden vorgeschlagen.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="min_revenue">Mindest-Umsatz (Mio EUR)</Label>
                  <Input
                    id="min_revenue"
                    type="number"
                    placeholder="100"
                    value={scoutSettings.minRevenueMio}
                    onChange={(e) => setScoutSettings({ ...scoutSettings, minRevenueMio: parseInt(e.target.value) || 0 })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Nur Firmen über diesem Umsatz</p>
                </div>
                <div>
                  <Label htmlFor="min_employees">Mindest-Mitarbeiter</Label>
                  <Input
                    id="min_employees"
                    type="number"
                    placeholder="500"
                    value={scoutSettings.minEmployees}
                    onChange={(e) => setScoutSettings({ ...scoutSettings, minEmployees: parseInt(e.target.value) || 0 })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Oder über dieser Mitarbeiterzahl</p>
                </div>
              </div>

              <div>
                <Label>Firmentypen (mehrfach wählbar)</Label>
                <div className="space-y-2 mt-2">
                  {['Manufacturer', 'Distributor', 'Service Provider'].map(type => (
                    <label key={type} className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        checked={scoutSettings.companyTypes.includes(type)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setScoutSettings({ ...scoutSettings, companyTypes: [...scoutSettings.companyTypes, type] });
                          } else {
                            setScoutSettings({ ...scoutSettings, companyTypes: scoutSettings.companyTypes.filter(t => t !== type) });
                          }
                        }}
                        className="rounded" 
                      />
                      <span className="text-sm">{type === 'Manufacturer' ? 'Hersteller' : type === 'Distributor' ? 'Händler' : 'Dienstleister'} ({type})</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <Label>Zielmärkte (Länder)</Label>
                <div className="grid grid-cols-5 gap-2 mt-2">
                  {['DE', 'US', 'UK', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'PL', 'SE', 'DK', 'NO', 'FI'].map(country => (
                    <label key={country} className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        checked={scoutSettings.targetMarkets.includes(country)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setScoutSettings({ ...scoutSettings, targetMarkets: [...scoutSettings.targetMarkets, country] });
                          } else {
                            setScoutSettings({ ...scoutSettings, targetMarkets: scoutSettings.targetMarkets.filter(c => c !== country) });
                          }
                        }}
                        className="rounded" 
                      />
                      <span className="text-sm font-mono">{country}</span>
                    </label>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">Top-15 Märkte für Competitor Discovery</p>
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button onClick={handleSaveScoutSettings} disabled={saveScoutSettingsMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  {saveScoutSettingsMutation.isPending ? 'Speichere...' : 'Filter speichern'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SMTP Tab */}
        <TabsContent value="smtp" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>SMTP / E-Mail Konfiguration</CardTitle>
              <CardDescription className="mb-4">
                ➡️ Ausgehende E-Mails: Konfiguriere hier deinen SMTP-Server, um E-Mails aus FRIDAY zu versenden (z.B. Outreach-Kampagnen, Newsletter, Benachrichtigungen).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="smtp_host">SMTP Host</Label>
                  <Input
                    id="smtp_host"
                    value={apiKeys.smtp_host || ''}
                    onChange={(e) => setApiKeys({ ...apiKeys, smtp_host: e.target.value })}
                    placeholder="mail.example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="smtp_port">SMTP Port</Label>
                  <Input
                    id="smtp_port"
                    value={apiKeys.smtp_port || ''}
                    onChange={(e) => setApiKeys({ ...apiKeys, smtp_port: e.target.value })}
                    placeholder="587"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="smtp_user">SMTP Username / E-Mail</Label>
                <Input
                  id="smtp_user"
                  value={apiKeys.smtp_user || ''}
                  onChange={(e) => setApiKeys({ ...apiKeys, smtp_user: e.target.value })}
                  placeholder="user@example.com"
                />
              </div>
              <div>
                <Label htmlFor="smtp_password">SMTP Password</Label>
                <div className="relative">
                  <Input
                    id="smtp_password"
                    type={showKeys.smtp_password ? 'text' : 'password'}
                    value={apiKeys.smtp_password || ''}
                    onChange={(e) => setApiKeys({ ...apiKeys, smtp_password: e.target.value })}
                    placeholder="••••••••"
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => toggleKeyVisibility('smtp_password')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showKeys.smtp_password ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => handleTestKey('smtp')}
                  disabled={!apiKeys.smtp_host || !apiKeys.smtp_user}
                >
                  SMTP Verbindung testen
                </Button>
                <Button onClick={handleSave} disabled={saveKeysMutation.isPending}>
                  <Save className="mr-2 h-4 w-4" />
                  Speichern
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Email Accounts Tab */}
        <TabsContent value="email-accounts" className="space-y-6">
          <EmailSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}
